/**
 * OrbitControls - Drag to rotate, scroll to zoom
 * Only rotates while actively dragging (pointer down + moving)
 */
(function() {
  'use strict';

  if (typeof THREE === 'undefined') {
    console.error('THREE.js must be loaded before OrbitControls');
    return;
  }

  const STATE = {
    NONE: -1,
    ROTATE: 0,
    DOLLY: 1,
    PAN: 2
  };

  THREE.OrbitControls = function(camera, domElement) {
    this.camera = camera;
    this.domElement = domElement;

    // Public API
    this.enabled = true;
    this.target = new THREE.Vector3();

    this.minDistance = 0;
    this.maxDistance = Infinity;

    this.minPolarAngle = 0;
    this.maxPolarAngle = Math.PI;

    this.minAzimuthAngle = -Infinity;
    this.maxAzimuthAngle = Infinity;

    this.enableDamping = false; // Disabled by default for precise control
    this.dampingFactor = 0.1;

    this.enableZoom = true;
    this.zoomSpeed = 1.0;

    this.enableRotate = true;
    this.rotateSpeed = 1.0;

    this.enablePan = true;
    this.panSpeed = 1.0;

    this.autoRotate = false;
    this.autoRotateSpeed = 2.0;

    // Internal state
    const scope = this;
    let state = STATE.NONE;
    let pointerDown = false;
    let activePointerId = null;

    const spherical = new THREE.Spherical();
    const sphericalDelta = new THREE.Spherical();

    let scale = 1;
    const panOffset = new THREE.Vector3();

    const rotateStart = new THREE.Vector2();
    const rotateEnd = new THREE.Vector2();
    const rotateDelta = new THREE.Vector2();

    const panStart = new THREE.Vector2();
    const panEnd = new THREE.Vector2();
    const panDelta = new THREE.Vector2();

    const dollyStart = new THREE.Vector2();
    const dollyEnd = new THREE.Vector2();
    const dollyDelta = new THREE.Vector2();

    // Pointer event handlers
    function onPointerDown(event) {
      if (!scope.enabled) return;

      // Only handle primary pointer
      if (activePointerId !== null) return;

      event.preventDefault();

      pointerDown = true;
      activePointerId = event.pointerId;

      // Capture pointer to receive events even outside element
      try {
        scope.domElement.setPointerCapture(event.pointerId);
      } catch (e) {
        // Fallback: add document listeners
      }

      const button = event.button;
      const isTouch = event.pointerType === 'touch';

      if (button === 0 || isTouch) {
        // Left click or touch
        if (event.ctrlKey || event.metaKey || event.shiftKey) {
          if (!scope.enablePan) return;
          panStart.set(event.clientX, event.clientY);
          state = STATE.PAN;
        } else {
          if (!scope.enableRotate) return;
          rotateStart.set(event.clientX, event.clientY);
          state = STATE.ROTATE;
        }
      } else if (button === 1) {
        // Middle click - dolly
        if (!scope.enableZoom) return;
        dollyStart.set(event.clientX, event.clientY);
        state = STATE.DOLLY;
      } else if (button === 2) {
        // Right click - pan
        if (!scope.enablePan) return;
        panStart.set(event.clientX, event.clientY);
        state = STATE.PAN;
      }
    }

    function onPointerMove(event) {
      if (!scope.enabled) return;
      if (!pointerDown) return;
      if (activePointerId !== event.pointerId) return;
      if (state === STATE.NONE) return;

      event.preventDefault();

      switch (state) {
        case STATE.ROTATE:
          if (!scope.enableRotate) return;

          rotateEnd.set(event.clientX, event.clientY);
          rotateDelta.subVectors(rotateEnd, rotateStart);
          rotateDelta.multiplyScalar(scope.rotateSpeed);

          const element = scope.domElement;

          // Rotate left-right
          sphericalDelta.theta -= (2 * Math.PI * rotateDelta.x) / element.clientHeight;
          // Rotate up-down
          sphericalDelta.phi -= (2 * Math.PI * rotateDelta.y) / element.clientHeight;

          rotateStart.copy(rotateEnd);
          scope.update();
          break;

        case STATE.DOLLY:
          if (!scope.enableZoom) return;

          dollyEnd.set(event.clientX, event.clientY);
          dollyDelta.subVectors(dollyEnd, dollyStart);

          if (dollyDelta.y > 0) {
            scale /= Math.pow(0.95, scope.zoomSpeed);
          } else if (dollyDelta.y < 0) {
            scale *= Math.pow(0.95, scope.zoomSpeed);
          }

          dollyStart.copy(dollyEnd);
          scope.update();
          break;

        case STATE.PAN:
          if (!scope.enablePan) return;

          panEnd.set(event.clientX, event.clientY);
          panDelta.subVectors(panEnd, panStart);
          panDelta.multiplyScalar(scope.panSpeed);

          const offset = new THREE.Vector3();
          const position = scope.camera.position;
          offset.copy(position).sub(scope.target);
          let targetDistance = offset.length();
          targetDistance *= Math.tan((scope.camera.fov / 2) * Math.PI / 180.0);

          // Pan left/right
          const v = new THREE.Vector3();
          v.setFromMatrixColumn(scope.camera.matrix, 0);
          v.multiplyScalar(-2 * panDelta.x * targetDistance / scope.domElement.clientHeight);
          panOffset.add(v);

          // Pan up/down
          v.setFromMatrixColumn(scope.camera.matrix, 1);
          v.multiplyScalar(2 * panDelta.y * targetDistance / scope.domElement.clientHeight);
          panOffset.add(v);

          panStart.copy(panEnd);
          scope.update();
          break;
      }
    }

    function onPointerUp(event) {
      if (activePointerId !== event.pointerId) return;

      pointerDown = false;
      activePointerId = null;
      state = STATE.NONE;

      // Clear deltas to stop any residual movement
      if (!scope.enableDamping) {
        sphericalDelta.set(0, 0, 0);
        panOffset.set(0, 0, 0);
      }

      try {
        scope.domElement.releasePointerCapture(event.pointerId);
      } catch (e) {
        // Ignore
      }
    }

    function onPointerCancel(event) {
      onPointerUp(event);
    }

    function onPointerLeave(event) {
      // If pointer leaves without an up event, treat as release
      if (pointerDown && activePointerId === event.pointerId) {
        onPointerUp(event);
      }
    }

    function onWheel(event) {
      if (!scope.enabled || !scope.enableZoom) return;

      event.preventDefault();
      event.stopPropagation();

      if (event.deltaY < 0) {
        scale *= Math.pow(0.95, scope.zoomSpeed);
      } else if (event.deltaY > 0) {
        scale /= Math.pow(0.95, scope.zoomSpeed);
      }

      scope.update();
    }

    function onContextMenu(event) {
      if (!scope.enabled) return;
      event.preventDefault();
    }

    // Update function
    this.update = (function() {
      const offset = new THREE.Vector3();
      const quat = new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        camera.up
      ).invert();
      const quatInverse = quat.clone().invert();
      const lastPosition = new THREE.Vector3();
      const lastQuaternion = new THREE.Quaternion();

      return function update() {
        const position = scope.camera.position;

        offset.copy(position).sub(scope.target);
        offset.applyQuaternion(quat);

        spherical.setFromVector3(offset);

        // Auto rotate only when not dragging
        if (scope.autoRotate && state === STATE.NONE && !pointerDown) {
          const autoRotateAngle = (2 * Math.PI / 60 / 60) * scope.autoRotateSpeed;
          spherical.theta -= autoRotateAngle;
        }

        // Apply rotation delta
        if (scope.enableDamping) {
          spherical.theta += sphericalDelta.theta * scope.dampingFactor;
          spherical.phi += sphericalDelta.phi * scope.dampingFactor;
        } else {
          spherical.theta += sphericalDelta.theta;
          spherical.phi += sphericalDelta.phi;
        }

        // Clamp phi (vertical angle)
        spherical.phi = Math.max(scope.minPolarAngle, Math.min(scope.maxPolarAngle, spherical.phi));
        spherical.makeSafe();

        // Apply zoom/scale
        spherical.radius *= scale;
        spherical.radius = Math.max(scope.minDistance, Math.min(scope.maxDistance, spherical.radius));

        // Apply pan
        if (scope.enableDamping) {
          scope.target.addScaledVector(panOffset, scope.dampingFactor);
        } else {
          scope.target.add(panOffset);
        }

        offset.setFromSpherical(spherical);
        offset.applyQuaternion(quatInverse);

        position.copy(scope.target).add(offset);
        scope.camera.lookAt(scope.target);

        // Apply damping decay or clear deltas
        if (scope.enableDamping) {
          sphericalDelta.theta *= (1 - scope.dampingFactor);
          sphericalDelta.phi *= (1 - scope.dampingFactor);
          panOffset.multiplyScalar(1 - scope.dampingFactor);
        } else {
          // Without damping, clear immediately after applying
          sphericalDelta.set(0, 0, 0);
          panOffset.set(0, 0, 0);
        }

        scale = 1;

        // Check if camera moved
        if (
          lastPosition.distanceToSquared(scope.camera.position) > 0.000001 ||
          8 * (1 - lastQuaternion.dot(scope.camera.quaternion)) > 0.000001
        ) {
          lastPosition.copy(scope.camera.position);
          lastQuaternion.copy(scope.camera.quaternion);
          return true;
        }

        return false;
      };
    })();

    // Reset to stop all movement
    this.reset = function() {
      sphericalDelta.set(0, 0, 0);
      panOffset.set(0, 0, 0);
      scale = 1;
    };

    this.dispose = function() {
      scope.domElement.removeEventListener('pointerdown', onPointerDown);
      scope.domElement.removeEventListener('pointermove', onPointerMove);
      scope.domElement.removeEventListener('pointerup', onPointerUp);
      scope.domElement.removeEventListener('pointercancel', onPointerCancel);
      scope.domElement.removeEventListener('pointerleave', onPointerLeave);
      scope.domElement.removeEventListener('wheel', onWheel);
      scope.domElement.removeEventListener('contextmenu', onContextMenu);
    };

    // Add event listeners with proper options
    scope.domElement.addEventListener('pointerdown', onPointerDown, { passive: false });
    scope.domElement.addEventListener('pointermove', onPointerMove, { passive: false });
    scope.domElement.addEventListener('pointerup', onPointerUp, { passive: false });
    scope.domElement.addEventListener('pointercancel', onPointerCancel, { passive: false });
    scope.domElement.addEventListener('pointerleave', onPointerLeave, { passive: false });
    scope.domElement.addEventListener('wheel', onWheel, { passive: false });
    scope.domElement.addEventListener('contextmenu', onContextMenu);

    // Ensure the element can receive pointer events
    scope.domElement.style.touchAction = 'none';
    scope.domElement.style.userSelect = 'none';

    // Initial update
    this.update();
  };

  THREE.OrbitControls.prototype = Object.create(THREE.EventDispatcher.prototype);
  THREE.OrbitControls.prototype.constructor = THREE.OrbitControls;

})();
