/**
 * GLTFLoader - Loader for GLTF/GLB files
 * Using CDN version compatible with legacy Three.js
 */
(function loadGLTFLoader() {
  'use strict';

  // Wait for THREE.js to be ready
  if (typeof THREE === 'undefined') {
    setTimeout(loadGLTFLoader, 50);
    return;
  }

  // Check if GLTFLoader already exists
  if (THREE.GLTFLoader) {
    return;
  }

  // Use threejsfundamentals CDN which has legacy builds
  const script = document.createElement('script');
  script.src = 'https://threejsfundamentals.org/threejs/resources/threejs/r132/examples/js/loaders/GLTFLoader.js';
  script.async = false;

  script.onload = function() {
    console.log('GLTFLoader loaded successfully');
  };

  script.onerror = function() {
    console.error('Failed to load GLTFLoader from CDN');
  };

  document.head.appendChild(script);
})();
