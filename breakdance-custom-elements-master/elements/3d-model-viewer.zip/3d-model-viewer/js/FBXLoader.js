/**
 * FBXLoader - Loader for FBX files
 * Using CDN version compatible with legacy Three.js
 */
(function loadFBXLoader() {
  'use strict';

  // Wait for THREE.js to be ready
  if (typeof THREE === 'undefined') {
    setTimeout(loadFBXLoader, 50);
    return;
  }

  // Check if FBXLoader already exists
  if (THREE.FBXLoader) {
    return;
  }

  // Use threejsfundamentals CDN which has legacy builds
  const script = document.createElement('script');
  script.src = 'https://threejsfundamentals.org/threejs/resources/threejs/r132/examples/js/loaders/FBXLoader.js';
  script.async = false;

  script.onload = function() {
    console.log('FBXLoader loaded successfully');
  };

  script.onerror = function() {
    console.error('Failed to load FBXLoader from CDN');
  };

  document.head.appendChild(script);
})();
