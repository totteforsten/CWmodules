/**
 * Breakdance 3D Model Viewer - Ultimate Three.js Engine
 * Advanced 3D rendering with physics, particles, primitives, and more
 */
(function initModelViewer() {
  'use strict';

  // Wait for THREE.js to be ready
  if (typeof THREE === 'undefined') {
    setTimeout(initModelViewer, 50);
    return;
  }

  window.BreakdanceModelViewer = window.BreakdanceModelViewer || {
    instances: {},

    /**
     * Strip alpha channel from hex color (convert #RRGGBBAA to #RRGGBB)
     */
    stripAlpha: function(color) {
      if (!color) return color;
      if (color.length === 9 && color.startsWith('#')) {
        return color.substring(0, 7);
      }
      return color;
    },

    /**
     * Parse JSON safely
     */
    parseJSON: function(str, fallback) {
      try {
        return str ? JSON.parse(str) : fallback;
      } catch (e) {
        return fallback;
      }
    },

    /**
     * Preset configurations are now handled by the Twig template.
     * The template outputs preset values directly into data attributes,
     * so the JavaScript just reads them like any other configuration.
     *
     * Available presets (configured in html.twig):
     * - fox_scroll: Fox with scroll animation (runs across screen on scroll)
     * - astronaut_float: Astronaut with floating bounce effect
     * - helmet_showcase: Helmet with auto-rotate showcase
     * - robot_interactive: Robot with animated character
     */

    /**
     * Initialize a new 3D model viewer instance
     */
    init: function(selector, id) {
      const wrapper = document.querySelector(selector + ' .model-viewer-wrapper');
      if (!wrapper) {
        console.error('Model viewer wrapper not found:', selector);
        return;
      }

      const canvasContainer = wrapper.querySelector('.model-viewer-canvas');
      if (!canvasContainer) {
        console.error('Canvas container not found');
        return;
      }

      // Get configuration from data attributes
      const config = this.getConfig(wrapper);

      // Create instance
      const instance = {
        id: id,
        selector: selector, // Store selector for update function
        wrapper: wrapper,
        canvasContainer: canvasContainer,
        config: config,
        scene: null,
        camera: null,
        renderer: null,
        controls: null,
        model: null,
        modelInstances: [],
        primitives: { planes: [], boxes: [], spheres: [], cylinders: [] },
        pointLights: [],
        spotLights: [],
        particleSystems: [],
        animationId: null,
        isLoaded: false,
        mixer: null,
        animations: [],
        activeActions: [],
        clock: new THREE.Clock(),
        isPlaying: false,
        currentTime: 0,
        duration: 0,
        customAnimationTime: 0,
        initialModelPosition: null,
        initialModelScale: null,
        // Physics state
        physics: {
          velocity: new THREE.Vector3(),
          angularVelocity: new THREE.Vector3(),
          isSimulating: false
        },
        // Raycaster for interactions
        raycaster: new THREE.Raycaster(),
        mouse: new THREE.Vector2(),
        hoveredObject: null,
        composer: null
      };

      // Initialize Three.js scene
      this.initScene(instance);

      // Load the 3D model
      if (config.modelUrl) {
        this.loadModel(instance);
      } else {
        // No model, just show primitives if any
        this.setupPrimitives(instance);
        this.hideLoading(instance);
        instance.isLoaded = true;
      }

      // Store instance
      this.instances[id] = instance;

      // Start render loop
      this.animate(instance);

      // Handle resize - store handler for cleanup
      instance.resizeHandler = () => this.onResize(instance);
      window.addEventListener('resize', instance.resizeHandler);

      // Setup interactions
      if (config.enableClick || config.enableHover || config.enableDrag) {
        this.setupInteractions(instance);
      }

      // Setup scroll animation
      if (config.enableScrollAnimation) {
        this.setupScrollAnimation(instance);
      }
    },

    /**
     * Get configuration from data attributes
     */
    getConfig: function(wrapper) {
      const stripAlpha = this.stripAlpha;
      const parseJSON = this.parseJSON;
      const presetName = wrapper.dataset.preset || '';

      let config = {
        // Model settings
        preset: presetName,
        modelType: wrapper.dataset.modelType || 'gltf',
        modelUrl: wrapper.dataset.modelUrl || '',
        textureUrl: wrapper.dataset.textureUrl || '',
        modelScale: parseFloat(wrapper.dataset.modelScale) || 1,
        initialPositionX: parseFloat(wrapper.dataset.initialPositionX) || 0,
        initialPositionY: parseFloat(wrapper.dataset.initialPositionY) || 0,
        initialPositionZ: parseFloat(wrapper.dataset.initialPositionZ) || 0,
        initialRotationX: parseFloat(wrapper.dataset.initialRotationX) || 0,
        initialRotationY: parseFloat(wrapper.dataset.initialRotationY) || 0,
        initialRotationZ: parseFloat(wrapper.dataset.initialRotationZ) || 0,
        centerModel: wrapper.dataset.centerModel !== 'false',
        autoFit: wrapper.dataset.autoFit !== 'false',

        // Camera settings
        cameraType: wrapper.dataset.cameraType || 'perspective',
        cameraFov: parseFloat(wrapper.dataset.cameraFov) || 45,
        orthoZoom: parseFloat(wrapper.dataset.orthoZoom) || 5,
        cameraPositionX: parseFloat(wrapper.dataset.cameraPositionX) || 0,
        cameraPositionY: parseFloat(wrapper.dataset.cameraPositionY) || 0,
        cameraPositionZ: parseFloat(wrapper.dataset.cameraPositionZ) || 5,
        cameraTargetX: parseFloat(wrapper.dataset.cameraTargetX) || 0,
        cameraTargetY: parseFloat(wrapper.dataset.cameraTargetY) || 0,
        cameraTargetZ: parseFloat(wrapper.dataset.cameraTargetZ) || 0,
        cameraNearClip: parseFloat(wrapper.dataset.cameraNearClip) || 0.1,
        cameraFarClip: parseFloat(wrapper.dataset.cameraFarClip) || 1000,
        autoRotate: wrapper.dataset.autoRotate === 'true',
        autoRotateSpeed: parseFloat(wrapper.dataset.autoRotateSpeed) || 2,

        // Lighting settings
        ambientIntensity: parseFloat(wrapper.dataset.ambientIntensity) || 1,
        ambientColor: stripAlpha(wrapper.dataset.ambientColor || '#ffffff'),
        directionalIntensity: parseFloat(wrapper.dataset.directionalIntensity) || 1,
        directionalColor: stripAlpha(wrapper.dataset.directionalColor || '#ffffff'),
        directionalPositionX: parseFloat(wrapper.dataset.directionalPositionX) || 5,
        directionalPositionY: parseFloat(wrapper.dataset.directionalPositionY) || 10,
        directionalPositionZ: parseFloat(wrapper.dataset.directionalPositionZ) || 5,
        hemisphereLight: wrapper.dataset.hemisphereLight === 'true',
        hemisphereSkyColor: stripAlpha(wrapper.dataset.hemisphereSkyColor || '#87ceeb'),
        hemisphereGroundColor: stripAlpha(wrapper.dataset.hemisphereGroundColor || '#8b4513'),
        hemisphereIntensity: parseFloat(wrapper.dataset.hemisphereIntensity) || 0.5,
        pointLights: parseJSON(wrapper.dataset.pointLights, []),
        spotLights: parseJSON(wrapper.dataset.spotLights, []),

        // Controls settings
        enableRotate: wrapper.dataset.enableRotate === 'true',
        rotateSpeed: parseFloat(wrapper.dataset.rotateSpeed) || 1,
        enableZoom: wrapper.dataset.enableZoom === 'true',
        minZoom: parseFloat(wrapper.dataset.minZoom) || 0.5,
        maxZoom: parseFloat(wrapper.dataset.maxZoom) || 5,
        enablePan: wrapper.dataset.enablePan === 'true',
        enableDamping: wrapper.dataset.enableDamping === 'true',
        dampingFactor: parseFloat(wrapper.dataset.dampingFactor) || 0.1,
        enableMouseTracking: wrapper.dataset.enableMouseTracking === 'true',
        maxRotationX: parseFloat(wrapper.dataset.maxRotationX) || 45,
        maxRotationY: parseFloat(wrapper.dataset.maxRotationY) || 45,
        mouseTrackingSpeed: parseFloat(wrapper.dataset.mouseTrackingSpeed) || 1,
        autoResumeAnimation: wrapper.dataset.autoResumeAnimation === 'true',

        // Shadow/environment settings
        enableShadows: wrapper.dataset.enableShadows === 'true',
        shadowGroundX: parseFloat(wrapper.dataset.shadowGroundX) || 0,
        shadowGroundY: parseFloat(wrapper.dataset.shadowGroundY) || -2,
        shadowGroundZ: parseFloat(wrapper.dataset.shadowGroundZ) || 0,
        shadowOpacity: parseFloat(wrapper.dataset.shadowOpacity) || 0.3,
        shadowGroundSize: parseFloat(wrapper.dataset.shadowGroundSize) || 20,
        shadowBlur: parseInt(wrapper.dataset.shadowBlur) || 2048,
        showGrid: wrapper.dataset.showGrid === 'true',
        showAxes: wrapper.dataset.showAxes === 'true',

        // Material settings
        enableColorOverride: wrapper.dataset.enableColorOverride === 'true',
        modelColor: stripAlpha(wrapper.dataset.modelColor || '#ffffff'),
        metalness: parseFloat(wrapper.dataset.metalness) || 0.5,
        roughness: parseFloat(wrapper.dataset.roughness) || 0.5,
        emissive: stripAlpha(wrapper.dataset.emissive || '#000000'),
        emissiveIntensity: parseFloat(wrapper.dataset.emissiveIntensity) || 0,

        // Animation settings
        enableAnimations: wrapper.dataset.enableAnimations === 'true',
        autoPlay: wrapper.dataset.autoPlay === 'true',
        loop: wrapper.dataset.loop === 'true',
        animationSpeed: parseFloat(wrapper.dataset.animationSpeed) || 1,
        animationType: wrapper.dataset.animationType || 'model',
        selectedAnimation: wrapper.dataset.selectedAnimation || 'all',
        animationIndex: parseInt(wrapper.dataset.animationIndex) || 0,
        customRotation: wrapper.dataset.customRotation === 'true',
        rotationAxis: wrapper.dataset.rotationAxis || 'y',
        customBounce: wrapper.dataset.customBounce === 'true',
        bounceHeight: parseFloat(wrapper.dataset.bounceHeight) || 1,
        customScalePulse: wrapper.dataset.customScalePulse === 'true',
        scaleAmount: parseFloat(wrapper.dataset.scaleAmount) || 0.2,
        timelineDuration: parseFloat(wrapper.dataset.timelineDuration) || 10,
        positionKeyframes: parseJSON(wrapper.dataset.positionKeyframes, []),
        rotationKeyframes: parseJSON(wrapper.dataset.rotationKeyframes, []),
        scaleKeyframes: parseJSON(wrapper.dataset.scaleKeyframes, []),

        // Background settings
        backgroundType: wrapper.dataset.backgroundType || 'color',
        backgroundColor: stripAlpha(wrapper.dataset.backgroundColor || '#1a1a1a'),

        // Depth of field
        enableDof: wrapper.dataset.enableDof === 'true',
        focusDistance: parseFloat(wrapper.dataset.focusDistance) || 5,
        aperture: parseFloat(wrapper.dataset.aperture) || 0.025,
        maxBlur: parseFloat(wrapper.dataset.maxBlur) || 0.01,

        // Physics settings
        enablePhysics: wrapper.dataset.enablePhysics === 'true',
        gravityStrength: parseFloat(wrapper.dataset.gravityStrength) || 9.8,
        gravityDirection: wrapper.dataset.gravityDirection || 'down',
        groundEnabled: wrapper.dataset.groundEnabled === 'true',
        groundPosition: parseFloat(wrapper.dataset.groundPosition) || -2,
        bounceFactor: parseFloat(wrapper.dataset.bounceFactor) || 0.5,
        friction: parseFloat(wrapper.dataset.friction) || 0.5,
        mass: parseFloat(wrapper.dataset.mass) || 1,
        airResistance: parseFloat(wrapper.dataset.airResistance) || 0.02,
        initialVelocityX: parseFloat(wrapper.dataset.initialVelocityX) || 0,
        initialVelocityY: parseFloat(wrapper.dataset.initialVelocityY) || 0,
        initialVelocityZ: parseFloat(wrapper.dataset.initialVelocityZ) || 0,
        angularVelocityX: parseFloat(wrapper.dataset.angularVelocityX) || 0,
        angularVelocityY: parseFloat(wrapper.dataset.angularVelocityY) || 0,
        angularVelocityZ: parseFloat(wrapper.dataset.angularVelocityZ) || 0,
        resetOnClick: wrapper.dataset.resetOnClick === 'true',

        // Environment & Skybox
        environmentType: wrapper.dataset.environmentType || 'none',
        environmentColor: stripAlpha(wrapper.dataset.environmentColor || '#1a1a1a'),
        gradientTopColor: stripAlpha(wrapper.dataset.gradientTopColor || '#87ceeb'),
        gradientBottomColor: stripAlpha(wrapper.dataset.gradientBottomColor || '#f0e68c'),
        hdriUrl: wrapper.dataset.hdriUrl || '',
        hdriIntensity: parseFloat(wrapper.dataset.hdriIntensity) || 1,
        hdriBlur: parseFloat(wrapper.dataset.hdriBlur) || 0,
        useAsLighting: wrapper.dataset.useAsLighting === 'true',
        cubemapPx: wrapper.dataset.cubemapPx || '',
        cubemapNx: wrapper.dataset.cubemapNx || '',
        cubemapPy: wrapper.dataset.cubemapPy || '',
        cubemapNy: wrapper.dataset.cubemapNy || '',
        cubemapPz: wrapper.dataset.cubemapPz || '',
        cubemapNz: wrapper.dataset.cubemapNz || '',
        environmentRotation: parseFloat(wrapper.dataset.environmentRotation) || 0,

        // Fog settings
        enableFog: wrapper.dataset.enableFog === 'true',
        fogType: wrapper.dataset.fogType || 'linear',
        fogColor: stripAlpha(wrapper.dataset.fogColor || '#cccccc'),
        fogNear: parseFloat(wrapper.dataset.fogNear) || 10,
        fogFar: parseFloat(wrapper.dataset.fogFar) || 100,
        fogDensity: parseFloat(wrapper.dataset.fogDensity) || 0.02,

        // Post-processing settings
        enableBloom: wrapper.dataset.enableBloom === 'true',
        bloomIntensity: parseFloat(wrapper.dataset.bloomIntensity) || 1,
        bloomThreshold: parseFloat(wrapper.dataset.bloomThreshold) || 0.8,
        bloomRadius: parseFloat(wrapper.dataset.bloomRadius) || 0.5,
        toneMapping: wrapper.dataset.toneMapping || 'none',
        toneMappingExposure: parseFloat(wrapper.dataset.toneMappingExposure) || 1,
        enableVignette: wrapper.dataset.enableVignette === 'true',
        vignetteIntensity: parseFloat(wrapper.dataset.vignetteIntensity) || 0.5,
        enableFilmGrain: wrapper.dataset.enableFilmGrain === 'true',
        filmGrainIntensity: parseFloat(wrapper.dataset.filmGrainIntensity) || 0.1,
        colorCorrection: wrapper.dataset.colorCorrection === 'true',
        saturation: parseFloat(wrapper.dataset.saturation) || 1,
        contrast: parseFloat(wrapper.dataset.contrast) || 1,
        brightness: parseFloat(wrapper.dataset.brightness) || 0,

        // Quality settings
        pixelRatio: wrapper.dataset.pixelRatio || 'auto',
        antialias: wrapper.dataset.antialias !== 'false',
        shadowQuality: wrapper.dataset.shadowQuality || 'medium',
        maxFps: parseInt(wrapper.dataset.maxFps) || 0,
        enableStats: wrapper.dataset.enableStats === 'true',

        // Model instances
        enableInstances: wrapper.dataset.enableInstances === 'true',
        instances: parseJSON(wrapper.dataset.instances, []),

        // Primitives
        planes: parseJSON(wrapper.dataset.planes, []),
        boxes: parseJSON(wrapper.dataset.boxes, []),
        spheres: parseJSON(wrapper.dataset.spheres, []),
        cylinders: parseJSON(wrapper.dataset.cylinders, []),

        // Particle systems
        particleSystems: parseJSON(wrapper.dataset.particleSystems, []),

        // Interactions
        enableClick: wrapper.dataset.enableClick === 'true',
        clickAction: wrapper.dataset.clickAction || 'none',
        highlightColor: stripAlpha(wrapper.dataset.highlightColor || '#ffff00'),
        enableHover: wrapper.dataset.enableHover === 'true',
        hoverEffect: wrapper.dataset.hoverEffect || 'outline',
        hoverColor: stripAlpha(wrapper.dataset.hoverColor || '#ffffff'),
        cursorStyle: wrapper.dataset.cursorStyle || 'pointer',
        enableDrag: wrapper.dataset.enableDrag === 'true',
        dragConstraint: wrapper.dataset.dragConstraint || 'free',
        enableScrollAnimation: wrapper.dataset.enableScrollAnimation === 'true',
        scrollAnimationType: wrapper.dataset.scrollAnimationType || 'rotate',
        scrollSpeed: parseFloat(wrapper.dataset.scrollSpeed) || 1,
        scrollTriggerStart: wrapper.dataset.scrollTriggerStart || 'top center',
        scrollTriggerEnd: wrapper.dataset.scrollTriggerEnd || 'bottom center',
        scrollScrub: wrapper.dataset.scrollScrub === 'true',
        scrollPin: wrapper.dataset.scrollPin === 'true',
        scrollPinOffset: wrapper.dataset.scrollPinOffset || '0px',
        scrollKeyframes: parseJSON(wrapper.dataset.scrollKeyframes, []),
        scrollDebug: wrapper.dataset.scrollDebug === 'true',
        enableTouchGestures: wrapper.dataset.enableTouchGestures === 'true',
        pinchToZoom: wrapper.dataset.pinchToZoom === 'true',
        twoFingerRotate: wrapper.dataset.twoFingerRotate === 'true'
      };

      // Presets are now applied via Twig template - data attributes already contain preset values
      // No JavaScript-side preset application needed

      return config;
    },

    /**
     * Initialize Three.js scene
     */
    initScene: function(instance) {
      const { canvasContainer, config } = instance;
      const width = canvasContainer.clientWidth;
      const height = canvasContainer.clientHeight;

      // Create scene
      instance.scene = new THREE.Scene();

      // Set background based on environment type
      this.setupEnvironment(instance);

      // Setup fog
      if (config.enableFog) {
        this.setupFog(instance);
      }

      // Create camera
      if (config.cameraType === 'orthographic') {
        const aspect = width / height;
        const zoom = config.orthoZoom;
        instance.camera = new THREE.OrthographicCamera(
          -zoom * aspect,
          zoom * aspect,
          zoom,
          -zoom,
          config.cameraNearClip,
          config.cameraFarClip
        );
        instance.camera.zoom = 1;
      } else {
        instance.camera = new THREE.PerspectiveCamera(
          config.cameraFov,
          width / height,
          config.cameraNearClip,
          config.cameraFarClip
        );
      }
      instance.camera.position.set(config.cameraPositionX, config.cameraPositionY, config.cameraPositionZ);

      // Determine pixel ratio
      let pixelRatio = window.devicePixelRatio;
      if (config.pixelRatio !== 'auto') {
        pixelRatio = parseFloat(config.pixelRatio);
      }

      // Create renderer
      instance.renderer = new THREE.WebGLRenderer({
        antialias: config.antialias,
        alpha: true,
        premultipliedAlpha: false,
        preserveDrawingBuffer: true
      });
      instance.renderer.setSize(width, height);
      instance.renderer.setPixelRatio(pixelRatio);
      instance.renderer.setClearColor(0x000000, 0);

      // Enable proper color management for GLTF models
      // This ensures textures and materials render with correct colors
      if (THREE.SRGBColorSpace !== undefined) {
        // Three.js r152+
        instance.renderer.outputColorSpace = THREE.SRGBColorSpace;
      } else if (THREE.sRGBEncoding !== undefined) {
        // Three.js r137-r151
        instance.renderer.outputEncoding = THREE.sRGBEncoding;
      }

      // Setup tone mapping
      this.setupToneMapping(instance);

      // Setup shadows
      if (config.enableShadows) {
        instance.renderer.shadowMap.enabled = true;
        instance.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        // Shadow quality
        const shadowSizes = { low: 512, medium: 1024, high: 2048, ultra: 4096 };
        instance.shadowMapSize = shadowSizes[config.shadowQuality] || 1024;
      }

      canvasContainer.appendChild(instance.renderer.domElement);

      // Add lights
      this.setupLights(instance);

      // Add additional lights (point and spot)
      this.setupAdditionalLights(instance);

      // Add ground plane for shadows
      if (config.enableShadows) {
        this.setupShadowGround(instance);
      }

      // Add helpers
      if (config.showGrid) {
        const gridHelper = new THREE.GridHelper(10, 10);
        instance.scene.add(gridHelper);
      }

      if (config.showAxes) {
        const axesHelper = new THREE.AxesHelper(5);
        instance.scene.add(axesHelper);
      }

      // Setup primitives
      this.setupPrimitives(instance);

      // Setup particle systems
      this.setupParticleSystems(instance);

      // Setup orbit controls
      this.waitForOrbitControls(() => {
        if (THREE.OrbitControls) {
          instance.controls = new THREE.OrbitControls(instance.camera, instance.renderer.domElement);
          instance.controls.target.set(config.cameraTargetX, config.cameraTargetY, config.cameraTargetZ);

          // Enable/disable drag to rotate (click and hold)
          instance.controls.enableRotate = config.enableRotate;
          instance.controls.rotateSpeed = config.rotateSpeed;

          instance.controls.enableZoom = config.enableZoom;
          instance.controls.minDistance = config.minZoom;
          instance.controls.maxDistance = config.maxZoom;
          instance.controls.enablePan = config.enablePan;
          instance.controls.enableDamping = config.enableDamping;
          instance.controls.dampingFactor = config.dampingFactor;
          instance.controls.autoRotate = config.autoRotate;
          instance.controls.autoRotateSpeed = config.autoRotateSpeed;
          instance.controls.update();
        }
      });

      // Setup mouse tracking
      if (config.enableMouseTracking) {
        this.setupMouseTracking(instance);
      }

      // Initialize physics
      if (config.enablePhysics) {
        this.initPhysics(instance);
      }

      // Setup FPS stats if enabled
      if (config.enableStats) {
        this.setupStats(instance);
      }
    },

    /**
     * Setup environment/background
     */
    setupEnvironment: function(instance) {
      const { scene, config } = instance;

      switch (config.environmentType) {
        case 'none':
          scene.background = null;
          break;

        case 'color':
          scene.background = new THREE.Color(config.environmentColor);
          break;

        case 'gradient':
          // Create gradient background using a large sphere
          const gradientCanvas = document.createElement('canvas');
          gradientCanvas.width = 2;
          gradientCanvas.height = 512;
          const ctx = gradientCanvas.getContext('2d');
          const gradient = ctx.createLinearGradient(0, 0, 0, 512);
          gradient.addColorStop(0, config.gradientTopColor);
          gradient.addColorStop(1, config.gradientBottomColor);
          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, 2, 512);

          const gradientTexture = new THREE.CanvasTexture(gradientCanvas);
          gradientTexture.mapping = THREE.EquirectangularReflectionMapping;
          scene.background = gradientTexture;
          break;

        case 'hdri':
          if (config.hdriUrl) {
            // Check for RGBELoader for HDR files
            const isHDR = config.hdriUrl.toLowerCase().endsWith('.hdr');
            if (isHDR && THREE.RGBELoader) {
              const loader = new THREE.RGBELoader();
              loader.load(config.hdriUrl, (texture) => {
                texture.mapping = THREE.EquirectangularReflectionMapping;
                scene.background = texture;
                if (config.useAsLighting) {
                  scene.environment = texture;
                }
              });
            } else {
              // Regular image skybox
              const loader = new THREE.TextureLoader();
              loader.load(config.hdriUrl, (texture) => {
                texture.mapping = THREE.EquirectangularReflectionMapping;
                scene.background = texture;
                if (config.useAsLighting) {
                  scene.environment = texture;
                }
              });
            }
          }
          break;

        case 'cubemap':
          if (config.cubemapPx && config.cubemapNx && config.cubemapPy &&
              config.cubemapNy && config.cubemapPz && config.cubemapNz) {
            const loader = new THREE.CubeTextureLoader();
            const cubeTexture = loader.load([
              config.cubemapPx, config.cubemapNx,
              config.cubemapPy, config.cubemapNy,
              config.cubemapPz, config.cubemapNz
            ]);
            scene.background = cubeTexture;
            if (config.useAsLighting) {
              scene.environment = cubeTexture;
            }
          }
          break;

        default:
          if (config.backgroundType === 'transparent') {
            scene.background = null;
          } else {
            scene.background = new THREE.Color(config.backgroundColor);
          }
      }
    },

    /**
     * Setup fog
     */
    setupFog: function(instance) {
      const { scene, config } = instance;
      const fogColor = new THREE.Color(config.fogColor);

      if (config.fogType === 'exponential') {
        scene.fog = new THREE.FogExp2(fogColor, config.fogDensity);
      } else {
        scene.fog = new THREE.Fog(fogColor, config.fogNear, config.fogFar);
      }
    },

    /**
     * Setup tone mapping
     */
    setupToneMapping: function(instance) {
      const { renderer, config } = instance;

      const toneMappingTypes = {
        none: THREE.NoToneMapping,
        linear: THREE.LinearToneMapping,
        reinhard: THREE.ReinhardToneMapping,
        cineon: THREE.CineonToneMapping,
        aces: THREE.ACESFilmicToneMapping
      };

      renderer.toneMapping = toneMappingTypes[config.toneMapping] || THREE.NoToneMapping;
      renderer.toneMappingExposure = config.toneMappingExposure;
    },

    /**
     * Setup main lights
     */
    setupLights: function(instance) {
      const { scene, config } = instance;

      // Ambient light
      const ambientLight = new THREE.AmbientLight(config.ambientColor, config.ambientIntensity);
      scene.add(ambientLight);

      // Directional light
      const directionalLight = new THREE.DirectionalLight(config.directionalColor, config.directionalIntensity);
      directionalLight.position.set(config.directionalPositionX, config.directionalPositionY, config.directionalPositionZ);

      if (config.enableShadows) {
        directionalLight.castShadow = true;
        const shadowSize = instance.shadowMapSize || 1024;
        directionalLight.shadow.mapSize.width = shadowSize;
        directionalLight.shadow.mapSize.height = shadowSize;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -10;
        directionalLight.shadow.camera.right = 10;
        directionalLight.shadow.camera.top = 10;
        directionalLight.shadow.camera.bottom = -10;

        // Store directional light reference for shadow tracking
        instance.directionalLight = directionalLight;
        instance.directionalLightBasePosition = {
          x: config.directionalPositionX,
          y: config.directionalPositionY,
          z: config.directionalPositionZ
        };

        // Add target to scene for proper shadow following
        scene.add(directionalLight.target);
      }

      scene.add(directionalLight);

      // Hemisphere light
      if (config.hemisphereLight) {
        const hemiLight = new THREE.HemisphereLight(
          config.hemisphereSkyColor,
          config.hemisphereGroundColor,
          config.hemisphereIntensity
        );
        scene.add(hemiLight);
      }

      // Fill light
      const fillLight = new THREE.DirectionalLight(0xffffff, 0.3);
      fillLight.position.set(-5, 0, -5);
      scene.add(fillLight);
    },

    /**
     * Setup additional point and spot lights
     */
    setupAdditionalLights: function(instance) {
      const { scene, config } = instance;

      // Point lights
      if (config.pointLights && config.pointLights.length > 0) {
        config.pointLights.forEach((lightData, index) => {
          const color = this.stripAlpha(lightData.color || '#ffffff');
          const intensity = parseFloat(lightData.intensity) || 1;
          const distance = parseFloat(lightData.distance) || 0;
          const decay = parseFloat(lightData.decay) || 2;

          const pointLight = new THREE.PointLight(color, intensity, distance, decay);
          pointLight.position.set(
            parseFloat(lightData.position_x) || 0,
            parseFloat(lightData.position_y) || 3,
            parseFloat(lightData.position_z) || 0
          );

          if (lightData.cast_shadow && config.enableShadows) {
            pointLight.castShadow = true;
            pointLight.shadow.mapSize.width = instance.shadowMapSize || 1024;
            pointLight.shadow.mapSize.height = instance.shadowMapSize || 1024;
          }

          scene.add(pointLight);
          instance.pointLights.push(pointLight);

          // Add helper if requested
          if (lightData.show_helper) {
            const helper = new THREE.PointLightHelper(pointLight, 0.5);
            scene.add(helper);
          }
        });
      }

      // Spot lights
      if (config.spotLights && config.spotLights.length > 0) {
        config.spotLights.forEach((lightData, index) => {
          const color = this.stripAlpha(lightData.color || '#ffffff');
          const intensity = parseFloat(lightData.intensity) || 1;
          const distance = parseFloat(lightData.distance) || 0;
          const angle = (parseFloat(lightData.angle) || 45) * Math.PI / 180;
          const penumbra = parseFloat(lightData.penumbra) || 0;
          const decay = parseFloat(lightData.decay) || 2;

          const spotLight = new THREE.SpotLight(color, intensity, distance, angle, penumbra, decay);
          spotLight.position.set(
            parseFloat(lightData.position_x) || 0,
            parseFloat(lightData.position_y) || 5,
            parseFloat(lightData.position_z) || 0
          );

          // Set target
          const target = new THREE.Object3D();
          target.position.set(
            parseFloat(lightData.target_x) || 0,
            parseFloat(lightData.target_y) || 0,
            parseFloat(lightData.target_z) || 0
          );
          scene.add(target);
          spotLight.target = target;

          if (lightData.cast_shadow && config.enableShadows) {
            spotLight.castShadow = true;
            spotLight.shadow.mapSize.width = instance.shadowMapSize || 1024;
            spotLight.shadow.mapSize.height = instance.shadowMapSize || 1024;
          }

          scene.add(spotLight);
          instance.spotLights.push(spotLight);

          // Add helper if requested
          if (lightData.show_helper) {
            const helper = new THREE.SpotLightHelper(spotLight);
            scene.add(helper);
          }
        });
      }
    },

    /**
     * Setup shadow ground plane
     */
    setupShadowGround: function(instance) {
      const { scene, config } = instance;
      const groundGeometry = new THREE.PlaneGeometry(config.shadowGroundSize, config.shadowGroundSize);
      const groundMaterial = new THREE.ShadowMaterial({ opacity: config.shadowOpacity });
      const ground = new THREE.Mesh(groundGeometry, groundMaterial);
      ground.rotation.x = -Math.PI / 2;
      ground.position.set(config.shadowGroundX, config.shadowGroundY, config.shadowGroundZ);
      ground.receiveShadow = true;
      scene.add(ground);

      // Store reference so we can move shadow with model
      instance.shadowGround = ground;
      instance.shadowGroundBaseY = config.shadowGroundY;
    },

    /**
     * Setup primitives (planes, boxes, spheres, cylinders)
     */
    setupPrimitives: function(instance) {
      const { scene, config } = instance;

      // Create material helper function
      const createMaterial = (data) => {
        const materialType = data.material_type || 'standard';
        const color = this.stripAlpha(data.color || '#cccccc');
        const opacity = parseFloat(data.opacity) || 1;
        const metalness = parseFloat(data.metalness) || 0;
        const roughness = parseFloat(data.roughness) || 0.5;
        const transparent = opacity < 1;
        const side = data.double_sided ? THREE.DoubleSide : THREE.FrontSide;

        let material;
        switch (materialType) {
          case 'basic':
            material = new THREE.MeshBasicMaterial({ color, opacity, transparent, side });
            break;
          case 'phong':
            material = new THREE.MeshPhongMaterial({ color, opacity, transparent, side, shininess: 30 });
            break;
          case 'lambert':
            material = new THREE.MeshLambertMaterial({ color, opacity, transparent, side });
            break;
          default:
            material = new THREE.MeshStandardMaterial({ color, opacity, transparent, side, metalness, roughness });
        }

        // Add texture if provided
        if (data.texture_url) {
          const loader = new THREE.TextureLoader();
          loader.load(data.texture_url, (texture) => {
            texture.wrapS = THREE.RepeatWrapping;
            texture.wrapT = THREE.RepeatWrapping;
            texture.repeat.set(
              parseFloat(data.texture_repeat_x) || 1,
              parseFloat(data.texture_repeat_y) || 1
            );
            material.map = texture;
            material.needsUpdate = true;
          });
        }

        return material;
      };

      // Helper to set transforms
      const setTransforms = (mesh, data) => {
        mesh.position.set(
          parseFloat(data.position_x) || 0,
          parseFloat(data.position_y) || 0,
          parseFloat(data.position_z) || 0
        );
        mesh.rotation.set(
          (parseFloat(data.rotation_x) || 0) * Math.PI / 180,
          (parseFloat(data.rotation_y) || 0) * Math.PI / 180,
          (parseFloat(data.rotation_z) || 0) * Math.PI / 180
        );
        if (data.cast_shadow) mesh.castShadow = true;
        if (data.receive_shadow) mesh.receiveShadow = true;
        if (data.visible === false) mesh.visible = false;
      };

      // Create planes
      if (config.planes && config.planes.length > 0) {
        config.planes.forEach((planeData) => {
          const width = parseFloat(planeData.width) || 10;
          const height = parseFloat(planeData.height) || 10;
          const geometry = new THREE.PlaneGeometry(width, height);
          const material = createMaterial(planeData);
          const plane = new THREE.Mesh(geometry, material);
          setTransforms(plane, planeData);
          scene.add(plane);
          instance.primitives.planes.push(plane);
        });
      }

      // Create boxes
      if (config.boxes && config.boxes.length > 0) {
        config.boxes.forEach((boxData) => {
          const width = parseFloat(boxData.width) || 1;
          const height = parseFloat(boxData.height) || 1;
          const depth = parseFloat(boxData.depth) || 1;
          const geometry = new THREE.BoxGeometry(width, height, depth);
          const material = createMaterial(boxData);
          const box = new THREE.Mesh(geometry, material);
          setTransforms(box, boxData);
          scene.add(box);
          instance.primitives.boxes.push(box);
        });
      }

      // Create spheres
      if (config.spheres && config.spheres.length > 0) {
        config.spheres.forEach((sphereData) => {
          const radius = parseFloat(sphereData.radius) || 1;
          const segments = parseInt(sphereData.segments) || 32;
          const geometry = new THREE.SphereGeometry(radius, segments, segments);
          const material = createMaterial(sphereData);

          // Handle emissive for spheres
          if (sphereData.emissive) {
            material.emissive = new THREE.Color(this.stripAlpha(sphereData.emissive));
            material.emissiveIntensity = parseFloat(sphereData.emissive_intensity) || 1;
          }

          const sphere = new THREE.Mesh(geometry, material);
          setTransforms(sphere, sphereData);
          scene.add(sphere);
          instance.primitives.spheres.push(sphere);
        });
      }

      // Create cylinders
      if (config.cylinders && config.cylinders.length > 0) {
        config.cylinders.forEach((cylData) => {
          const radiusTop = parseFloat(cylData.radius_top) || 1;
          const radiusBottom = parseFloat(cylData.radius_bottom) || 1;
          const height = parseFloat(cylData.height) || 2;
          const segments = parseInt(cylData.segments) || 32;
          const geometry = new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments);
          const material = createMaterial(cylData);
          const cylinder = new THREE.Mesh(geometry, material);
          setTransforms(cylinder, cylData);
          scene.add(cylinder);
          instance.primitives.cylinders.push(cylinder);
        });
      }
    },

    /**
     * Get preset configuration for particle types
     */
    getParticlePreset: function(type) {
      const presets = {
        snow: {
          count: 2000,
          size: 0.08,
          color: '#ffffff',
          opacity: 0.9,
          velocityX: 0,
          velocityY: -1.5,
          velocityZ: 0,
          spreadX: 20,
          spreadY: 15,
          spreadZ: 20,
          turbulence: 0.8,
          lifespan: 8,
          gravity: 0,
          fadeIn: true,
          fadeOut: true,
          sizeOverLife: false,
          wobble: true,
          wobbleSpeed: 2,
          wobbleAmount: 0.5
        },
        rain: {
          count: 3000,
          size: 0.03,
          color: '#a0c4e8',
          opacity: 0.6,
          velocityX: 0.5,
          velocityY: -15,
          velocityZ: 0,
          spreadX: 25,
          spreadY: 20,
          spreadZ: 25,
          turbulence: 0.2,
          lifespan: 2,
          gravity: 5,
          fadeIn: false,
          fadeOut: true,
          sizeOverLife: false,
          wobble: false
        },
        fire: {
          count: 800,
          size: 0.25,
          color: '#ff6600',
          colorEnd: '#ffff00',
          opacity: 0.85,
          velocityX: 0,
          velocityY: 3,
          velocityZ: 0,
          spreadX: 1.5,
          spreadY: 0.5,
          spreadZ: 1.5,
          turbulence: 1.5,
          lifespan: 1.5,
          gravity: -2,
          fadeIn: true,
          fadeOut: true,
          sizeOverLife: true,
          sizeEnd: 0.05,
          additive: true,
          wobble: true,
          wobbleSpeed: 8,
          wobbleAmount: 0.3
        },
        sparkles: {
          count: 500,
          size: 0.12,
          color: '#ffffff',
          opacity: 1,
          velocityX: 0,
          velocityY: 0.5,
          velocityZ: 0,
          spreadX: 8,
          spreadY: 8,
          spreadZ: 8,
          turbulence: 2,
          lifespan: 3,
          gravity: -0.5,
          fadeIn: true,
          fadeOut: true,
          sizeOverLife: true,
          sizeEnd: 0,
          twinkle: true,
          twinkleSpeed: 10,
          additive: true
        },
        dust: {
          count: 600,
          size: 0.04,
          color: '#d4c4a8',
          opacity: 0.4,
          velocityX: 0.1,
          velocityY: 0.05,
          velocityZ: 0.1,
          spreadX: 15,
          spreadY: 10,
          spreadZ: 15,
          turbulence: 0.3,
          lifespan: 12,
          gravity: 0,
          fadeIn: true,
          fadeOut: true,
          sizeOverLife: false,
          drift: true,
          driftSpeed: 0.5
        },
        smoke: {
          count: 400,
          size: 0.5,
          color: '#888888',
          opacity: 0.3,
          velocityX: 0,
          velocityY: 1,
          velocityZ: 0,
          spreadX: 2,
          spreadY: 0.5,
          spreadZ: 2,
          turbulence: 1,
          lifespan: 5,
          gravity: -0.3,
          fadeIn: true,
          fadeOut: true,
          sizeOverLife: true,
          sizeEnd: 1.5,
          wobble: true,
          wobbleSpeed: 1,
          wobbleAmount: 0.8
        },
        confetti: {
          count: 300,
          size: 0.15,
          color: '#ff0000',
          colorVariation: true,
          opacity: 1,
          velocityX: 0,
          velocityY: -2,
          velocityZ: 0,
          spreadX: 10,
          spreadY: 5,
          spreadZ: 10,
          turbulence: 3,
          lifespan: 6,
          gravity: 2,
          fadeIn: false,
          fadeOut: true,
          sizeOverLife: false,
          spin: true,
          spinSpeed: 5
        }
      };
      return presets[type] || null;
    },

    /**
     * Setup particle systems
     */
    setupParticleSystems: function(instance) {
      const { scene, config } = instance;
      const self = this;

      if (!config.particleSystems || config.particleSystems.length === 0) return;

      config.particleSystems.forEach((sysData) => {
        if (sysData.visible === false) return;

        // Get preset if specified, otherwise use custom values
        const particleType = sysData.particle_type || 'points';
        const preset = this.getParticlePreset(particleType);

        // Merge preset with custom values (custom values override preset)
        const cfg = {
          count: parseInt(sysData.particle_count) || (preset ? preset.count : 1000),
          size: parseFloat(sysData.particle_size) || (preset ? preset.size : 0.1),
          color: this.stripAlpha(sysData.particle_color) || (preset ? preset.color : '#ffffff'),
          colorEnd: preset ? preset.colorEnd : null,
          colorVariation: preset ? preset.colorVariation : false,
          opacity: parseFloat(sysData.particle_opacity) || (preset ? preset.opacity : 1),
          spreadX: parseFloat(sysData.spread_x) || (preset ? preset.spreadX : 10),
          spreadY: parseFloat(sysData.spread_y) || (preset ? preset.spreadY : 10),
          spreadZ: parseFloat(sysData.spread_z) || (preset ? preset.spreadZ : 10),
          emitterX: parseFloat(sysData.emitter_position_x) || 0,
          emitterY: parseFloat(sysData.emitter_position_y) || 0,
          emitterZ: parseFloat(sysData.emitter_position_z) || 0,
          velocityX: parseFloat(sysData.velocity_x) || (preset ? preset.velocityX : 0),
          velocityY: parseFloat(sysData.velocity_y) || (preset ? preset.velocityY : 0),
          velocityZ: parseFloat(sysData.velocity_z) || (preset ? preset.velocityZ : 0),
          turbulence: parseFloat(sysData.turbulence) || (preset ? preset.turbulence : 0),
          lifespan: parseFloat(sysData.life_span) || (preset ? preset.lifespan : 5),
          gravity: parseFloat(sysData.gravity) || (preset ? preset.gravity : 0),
          fadeIn: sysData.fade_in !== undefined ? sysData.fade_in : (preset ? preset.fadeIn : false),
          fadeOut: sysData.fade_out !== undefined ? sysData.fade_out : (preset ? preset.fadeOut : false),
          sizeOverLife: sysData.size_over_life || (preset ? preset.sizeOverLife : false),
          sizeEnd: parseFloat(sysData.size_end) || (preset ? preset.sizeEnd : 0),
          additive: sysData.additive_blending || (preset ? preset.additive : false),
          wobble: preset ? preset.wobble : false,
          wobbleSpeed: preset ? preset.wobbleSpeed : 2,
          wobbleAmount: preset ? preset.wobbleAmount : 0.5,
          twinkle: preset ? preset.twinkle : false,
          twinkleSpeed: preset ? preset.twinkleSpeed : 10,
          drift: preset ? preset.drift : false,
          driftSpeed: preset ? preset.driftSpeed : 0.5
        };

        const count = cfg.count;

        // Create geometry with attributes
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(count * 3);
        const velocities = new Float32Array(count * 3);
        const lifetimes = new Float32Array(count);
        const startLifetimes = new Float32Array(count);
        const sizes = new Float32Array(count);
        const colors = new Float32Array(count * 3);
        const alphas = new Float32Array(count);
        const randoms = new Float32Array(count);

        // Parse colors
        const baseColor = new THREE.Color(cfg.color);
        const endColor = cfg.colorEnd ? new THREE.Color(cfg.colorEnd) : baseColor;

        // Confetti color palette
        const confettiColors = [
          new THREE.Color('#ff0000'),
          new THREE.Color('#00ff00'),
          new THREE.Color('#0000ff'),
          new THREE.Color('#ffff00'),
          new THREE.Color('#ff00ff'),
          new THREE.Color('#00ffff'),
          new THREE.Color('#ff8800'),
          new THREE.Color('#ff0088')
        ];

        // Initialize particles
        for (let i = 0; i < count; i++) {
          // Random spawn position
          positions[i * 3] = cfg.emitterX + (Math.random() - 0.5) * cfg.spreadX;
          positions[i * 3 + 1] = cfg.emitterY + (Math.random() - 0.5) * cfg.spreadY;
          positions[i * 3 + 2] = cfg.emitterZ + (Math.random() - 0.5) * cfg.spreadZ;

          // Velocity with turbulence
          velocities[i * 3] = cfg.velocityX + (Math.random() - 0.5) * cfg.turbulence;
          velocities[i * 3 + 1] = cfg.velocityY + (Math.random() - 0.5) * cfg.turbulence;
          velocities[i * 3 + 2] = cfg.velocityZ + (Math.random() - 0.5) * cfg.turbulence;

          // Stagger start times for more natural look
          const startTime = Math.random() * cfg.lifespan;
          lifetimes[i] = startTime;
          startLifetimes[i] = startTime;

          // Initial size
          sizes[i] = cfg.size * (0.8 + Math.random() * 0.4); // 80-120% size variation

          // Color (with optional variation)
          let particleColor = baseColor;
          if (cfg.colorVariation) {
            particleColor = confettiColors[Math.floor(Math.random() * confettiColors.length)];
          }
          colors[i * 3] = particleColor.r;
          colors[i * 3 + 1] = particleColor.g;
          colors[i * 3 + 2] = particleColor.b;

          // Alpha
          alphas[i] = cfg.opacity;

          // Random seed for effects
          randoms[i] = Math.random() * Math.PI * 2;
        }

        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('customSize', new THREE.BufferAttribute(sizes, 1));
        geometry.setAttribute('customColor', new THREE.BufferAttribute(colors, 3));
        geometry.setAttribute('customAlpha', new THREE.BufferAttribute(alphas, 1));

        // Create shader material for advanced effects
        const vertexShader = `
          attribute float customSize;
          attribute vec3 customColor;
          attribute float customAlpha;
          varying vec3 vColor;
          varying float vAlpha;
          void main() {
            vColor = customColor;
            vAlpha = customAlpha;
            vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
            gl_PointSize = customSize * (300.0 / -mvPosition.z);
            gl_Position = projectionMatrix * mvPosition;
          }
        `;

        const fragmentShader = `
          varying vec3 vColor;
          varying float vAlpha;
          void main() {
            float dist = length(gl_PointCoord - vec2(0.5));
            if (dist > 0.5) discard;
            float alpha = vAlpha * (1.0 - smoothstep(0.3, 0.5, dist));
            gl_FragColor = vec4(vColor, alpha);
          }
        `;

        let material;

        // Use simple material for compatibility, but with good settings
        const materialParams = {
          size: cfg.size,
          transparent: true,
          opacity: cfg.opacity,
          depthWrite: false,
          vertexColors: true,
          sizeAttenuation: true
        };

        if (cfg.additive) {
          materialParams.blending = THREE.AdditiveBlending;
        }

        // Load texture if provided
        if (sysData.texture_url) {
          const loader = new THREE.TextureLoader();
          loader.load(sysData.texture_url, (texture) => {
            material.map = texture;
            material.needsUpdate = true;
          });
        }

        material = new THREE.PointsMaterial(materialParams);
        const particles = new THREE.Points(geometry, material);

        scene.add(particles);

        instance.particleSystems.push({
          particles: particles,
          velocities: velocities,
          lifetimes: lifetimes,
          startLifetimes: startLifetimes,
          baseSizes: sizes.slice(),
          baseColors: colors.slice(),
          randoms: randoms,
          config: cfg,
          preset: preset,
          time: 0
        });
      });
    },

    /**
     * Update particle systems with advanced physics and effects
     */
    updateParticleSystems: function(instance, delta) {
      instance.particleSystems.forEach((system) => {
        const positions = system.particles.geometry.attributes.position.array;
        const sizes = system.particles.geometry.attributes.customSize ?
                     system.particles.geometry.attributes.customSize.array : null;
        const colors = system.particles.geometry.attributes.customColor ?
                      system.particles.geometry.attributes.customColor.array : null;
        const alphas = system.particles.geometry.attributes.customAlpha ?
                      system.particles.geometry.attributes.customAlpha.array : null;

        const velocities = system.velocities;
        const cfg = system.config;
        const count = positions.length / 3;

        system.time += delta;

        for (let i = 0; i < count; i++) {
          system.lifetimes[i] += delta;
          const life = system.lifetimes[i];
          const lifeRatio = Math.min(life / cfg.lifespan, 1);

          // Reset particle if lifetime exceeded
          if (life >= cfg.lifespan) {
            // Respawn at emitter
            positions[i * 3] = cfg.emitterX + (Math.random() - 0.5) * cfg.spreadX;
            positions[i * 3 + 1] = cfg.emitterY + (Math.random() - 0.5) * cfg.spreadY;
            positions[i * 3 + 2] = cfg.emitterZ + (Math.random() - 0.5) * cfg.spreadZ;

            // Reset velocity with new turbulence
            velocities[i * 3] = cfg.velocityX + (Math.random() - 0.5) * cfg.turbulence;
            velocities[i * 3 + 1] = cfg.velocityY + (Math.random() - 0.5) * cfg.turbulence;
            velocities[i * 3 + 2] = cfg.velocityZ + (Math.random() - 0.5) * cfg.turbulence;

            system.lifetimes[i] = 0;
            system.randoms[i] = Math.random() * Math.PI * 2;

            // Reset size
            if (sizes) {
              sizes[i] = system.baseSizes[i];
            }

            // Reset alpha
            if (alphas) {
              alphas[i] = cfg.opacity;
            }
          } else {
            // Apply gravity to velocity
            if (cfg.gravity !== 0) {
              velocities[i * 3 + 1] -= cfg.gravity * delta;
            }

            // Apply wobble effect (snow, smoke)
            if (cfg.wobble) {
              const wobbleOffset = Math.sin(system.time * cfg.wobbleSpeed + system.randoms[i]) * cfg.wobbleAmount * delta;
              positions[i * 3] += wobbleOffset;
              positions[i * 3 + 2] += Math.cos(system.time * cfg.wobbleSpeed + system.randoms[i]) * cfg.wobbleAmount * delta;
            }

            // Apply drift effect (dust)
            if (cfg.drift) {
              const driftX = Math.sin(system.time * cfg.driftSpeed + system.randoms[i]) * delta * 0.5;
              const driftZ = Math.cos(system.time * cfg.driftSpeed * 0.7 + system.randoms[i]) * delta * 0.5;
              positions[i * 3] += driftX;
              positions[i * 3 + 2] += driftZ;
            }

            // Move particle by velocity
            positions[i * 3] += velocities[i * 3] * delta;
            positions[i * 3 + 1] += velocities[i * 3 + 1] * delta;
            positions[i * 3 + 2] += velocities[i * 3 + 2] * delta;

            // Fade in/out
            if (alphas) {
              let alpha = cfg.opacity;

              if (cfg.fadeIn && lifeRatio < 0.2) {
                alpha *= lifeRatio / 0.2;
              }
              if (cfg.fadeOut && lifeRatio > 0.7) {
                alpha *= 1 - (lifeRatio - 0.7) / 0.3;
              }

              // Twinkle effect (sparkles)
              if (cfg.twinkle) {
                alpha *= 0.5 + 0.5 * Math.sin(system.time * cfg.twinkleSpeed + system.randoms[i] * 10);
              }

              alphas[i] = Math.max(0, alpha);
            }

            // Size over life
            if (sizes && cfg.sizeOverLife) {
              const startSize = system.baseSizes[i];
              const endSize = cfg.sizeEnd || 0;
              sizes[i] = startSize + (endSize - startSize) * lifeRatio;
            }

            // Color interpolation (fire effect)
            if (colors && cfg.colorEnd) {
              const startColor = new THREE.Color(cfg.color);
              const endColor = new THREE.Color(cfg.colorEnd);
              colors[i * 3] = startColor.r + (endColor.r - startColor.r) * lifeRatio;
              colors[i * 3 + 1] = startColor.g + (endColor.g - startColor.g) * lifeRatio;
              colors[i * 3 + 2] = startColor.b + (endColor.b - startColor.b) * lifeRatio;
            }
          }
        }

        // Update geometry
        system.particles.geometry.attributes.position.needsUpdate = true;
        if (sizes) system.particles.geometry.attributes.customSize.needsUpdate = true;
        if (colors) system.particles.geometry.attributes.customColor.needsUpdate = true;
        if (alphas) system.particles.geometry.attributes.customAlpha.needsUpdate = true;
      });
    },

    /**
     * Initialize physics
     */
    initPhysics: function(instance) {
      const { config } = instance;

      instance.physics = {
        velocity: new THREE.Vector3(
          config.initialVelocityX,
          config.initialVelocityY,
          config.initialVelocityZ
        ),
        angularVelocity: new THREE.Vector3(
          config.angularVelocityX,
          config.angularVelocityY,
          config.angularVelocityZ
        ),
        isSimulating: true
      };

      // Setup click to reset
      if (config.resetOnClick) {
        instance.wrapper.addEventListener('click', () => {
          this.resetPhysics(instance);
        });
      }
    },

    /**
     * Reset physics simulation
     */
    resetPhysics: function(instance) {
      const { config } = instance;

      if (instance.model && instance.initialModelPosition) {
        instance.model.position.copy(instance.initialModelPosition);
        instance.model.rotation.set(0, 0, 0);
      }

      instance.physics.velocity.set(
        config.initialVelocityX,
        config.initialVelocityY,
        config.initialVelocityZ
      );
      instance.physics.angularVelocity.set(
        config.angularVelocityX,
        config.angularVelocityY,
        config.angularVelocityZ
      );
      instance.physics.isSimulating = true;
    },

    /**
     * Update physics simulation
     */
    updatePhysics: function(instance, delta) {
      if (!instance.config.enablePhysics || !instance.model || !instance.physics.isSimulating) return;

      const { config, physics } = instance;

      // Get gravity direction vector
      const gravity = new THREE.Vector3();
      switch (config.gravityDirection) {
        case 'up': gravity.set(0, config.gravityStrength, 0); break;
        case 'left': gravity.set(-config.gravityStrength, 0, 0); break;
        case 'right': gravity.set(config.gravityStrength, 0, 0); break;
        case 'forward': gravity.set(0, 0, -config.gravityStrength); break;
        case 'backward': gravity.set(0, 0, config.gravityStrength); break;
        default: gravity.set(0, -config.gravityStrength, 0); // down
      }

      // Apply gravity to velocity
      physics.velocity.addScaledVector(gravity, delta);

      // Apply air resistance
      physics.velocity.multiplyScalar(1 - config.airResistance);
      physics.angularVelocity.multiplyScalar(1 - config.airResistance);

      // Update position
      instance.model.position.addScaledVector(physics.velocity, delta);

      // Update rotation
      instance.model.rotation.x += physics.angularVelocity.x * delta;
      instance.model.rotation.y += physics.angularVelocity.y * delta;
      instance.model.rotation.z += physics.angularVelocity.z * delta;

      // Ground collision
      if (config.groundEnabled) {
        const groundY = config.groundPosition;

        // Get model bounding box
        const box = new THREE.Box3().setFromObject(instance.model);
        const modelBottom = box.min.y;

        if (modelBottom <= groundY) {
          // Collision detected
          const offset = groundY - modelBottom;
          instance.model.position.y += offset;

          // Bounce
          if (Math.abs(physics.velocity.y) > 0.1) {
            physics.velocity.y *= -config.bounceFactor;
          } else {
            physics.velocity.y = 0;
          }

          // Friction on ground
          physics.velocity.x *= (1 - config.friction);
          physics.velocity.z *= (1 - config.friction);
          physics.angularVelocity.multiplyScalar(1 - config.friction);

          // Stop simulation if velocities are very small
          if (physics.velocity.length() < 0.01 && physics.angularVelocity.length() < 0.01) {
            physics.isSimulating = false;
          }
        }
      }
    },

    /**
     * Wait for OrbitControls to be loaded
     */
    waitForOrbitControls: function(callback, attempts = 0) {
      if (THREE.OrbitControls) {
        callback();
      } else if (attempts < 50) {
        setTimeout(() => this.waitForOrbitControls(callback, attempts + 1), 100);
      } else {
        console.warn('OrbitControls not loaded after 5 seconds');
      }
    },

    /**
     * Setup mouse tracking for model rotation
     */
    setupMouseTracking: function(instance) {
      const { wrapper, config } = instance;

      instance.mouseTracking = {
        isHovering: false,
        mouseX: 0,
        mouseY: 0,
        targetRotationX: 0,
        targetRotationY: 0,
        currentRotationX: 0,
        currentRotationY: 0,
        animationStatePaused: false
      };

      const maxRotX = (config.maxRotationX * Math.PI) / 180;
      const maxRotY = (config.maxRotationY * Math.PI) / 180;

      const onMouseMove = (event) => {
        if (!instance.mouseTracking.isHovering) return;
        const rect = wrapper.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        const normalizedX = (x / rect.width) * 2 - 1;
        const normalizedY = (y / rect.height) * 2 - 1;
        instance.mouseTracking.targetRotationY = normalizedX * maxRotY;
        instance.mouseTracking.targetRotationX = -normalizedY * maxRotX;
      };

      const onMouseEnter = () => {
        instance.mouseTracking.isHovering = true;
        instance.mouseTracking.needsRotationUpdate = true; // Flag to capture current rotation as base
        instance.mouseTracking.currentRotationX = 0;
        instance.mouseTracking.currentRotationY = 0;
        instance.mouseTracking.targetRotationX = 0;
        instance.mouseTracking.targetRotationY = 0;
        if (instance.controls) instance.controls.enableRotate = false;
        if (config.autoResumeAnimation) {
          instance.mouseTracking.animationStatePaused = true;
          if (instance.controls) instance.controls.autoRotate = false;
          if (instance.isPlaying) {
            instance.mouseTracking.wasPlaying = true;
            instance.isPlaying = false;
          }
        }
      };

      const onMouseLeave = () => {
        instance.mouseTracking.isHovering = false;
        instance.mouseTracking.modelOriginalRotation = null; // Clear so it gets recaptured next hover
        if (instance.controls) instance.controls.enableRotate = true;
        if (config.autoResumeAnimation && instance.mouseTracking.animationStatePaused) {
          instance.mouseTracking.animationStatePaused = false;
          if (instance.controls && config.autoRotate) instance.controls.autoRotate = true;
          if (instance.mouseTracking.wasPlaying) {
            instance.isPlaying = true;
            instance.mouseTracking.wasPlaying = false;
          }
        }
        // Reset target rotation for smooth return
        instance.mouseTracking.targetRotationX = 0;
        instance.mouseTracking.targetRotationY = 0;
      };

      wrapper.addEventListener('mousemove', onMouseMove);
      wrapper.addEventListener('mouseenter', onMouseEnter);
      wrapper.addEventListener('mouseleave', onMouseLeave);

      instance.mouseTracking.cleanup = () => {
        wrapper.removeEventListener('mousemove', onMouseMove);
        wrapper.removeEventListener('mouseenter', onMouseEnter);
        wrapper.removeEventListener('mouseleave', onMouseLeave);
      };
    },

    /**
     * Apply mouse tracking rotation
     */
    applyMouseTracking: function(instance) {
      if (!instance.mouseTracking || !instance.model) return;

      const tracking = instance.mouseTracking;
      const config = instance.config;
      const speed = config.mouseTrackingSpeed * 0.1;

      // Smoothly interpolate current rotation towards target
      tracking.currentRotationX += (tracking.targetRotationX - tracking.currentRotationX) * speed;
      tracking.currentRotationY += (tracking.targetRotationY - tracking.currentRotationY) * speed;

      if (tracking.isHovering) {
        // Use the current model rotation as base if we just started hovering
        if (!tracking.modelOriginalRotation || tracking.needsRotationUpdate) {
          tracking.modelOriginalRotation = {
            x: instance.model.rotation.x,
            y: instance.model.rotation.y,
            z: instance.model.rotation.z
          };
          tracking.needsRotationUpdate = false;
        }

        // Apply the mouse tracking offset to the original rotation
        instance.model.rotation.x = tracking.modelOriginalRotation.x + tracking.currentRotationX;
        instance.model.rotation.y = tracking.modelOriginalRotation.y + tracking.currentRotationY;
      }
    },

    /**
     * Setup interactions (click, hover, drag)
     */
    setupInteractions: function(instance) {
      const { wrapper, config, camera } = instance;

      const onMouseMove = (event) => {
        const rect = wrapper.getBoundingClientRect();
        instance.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        instance.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        if (config.enableHover) {
          this.handleHover(instance);
        }
      };

      const onClick = (event) => {
        if (!config.enableClick) return;

        instance.raycaster.setFromCamera(instance.mouse, camera);
        const intersects = instance.raycaster.intersectObjects(instance.scene.children, true);

        if (intersects.length > 0) {
          const object = intersects[0].object;
          this.handleClick(instance, object);
        }
      };

      wrapper.addEventListener('mousemove', onMouseMove);
      wrapper.addEventListener('click', onClick);

      // Set cursor style
      wrapper.style.cursor = config.cursorStyle;
    },

    /**
     * Handle hover effects
     */
    handleHover: function(instance) {
      const { camera, config, scene, mouse, raycaster } = instance;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(scene.children, true);

      if (intersects.length > 0) {
        const object = intersects[0].object;

        if (instance.hoveredObject !== object) {
          // Restore previous object
          if (instance.hoveredObject && instance.hoveredObject._originalMaterial) {
            instance.hoveredObject.material = instance.hoveredObject._originalMaterial;
          }

          instance.hoveredObject = object;

          if (object.material) {
            object._originalMaterial = object.material;

            switch (config.hoverEffect) {
              case 'glow':
              case 'color':
                const newMat = object.material.clone();
                newMat.emissive = new THREE.Color(config.hoverColor);
                newMat.emissiveIntensity = 0.5;
                object.material = newMat;
                break;
              case 'scale':
                object.scale.multiplyScalar(1.1);
                break;
            }
          }
        }
      } else {
        // No intersection, restore hovered object
        if (instance.hoveredObject) {
          if (instance.hoveredObject._originalMaterial) {
            instance.hoveredObject.material = instance.hoveredObject._originalMaterial;
          }
          if (config.hoverEffect === 'scale') {
            instance.hoveredObject.scale.divideScalar(1.1);
          }
          instance.hoveredObject = null;
        }
      }
    },

    /**
     * Handle click action
     */
    handleClick: function(instance, object) {
      const { config } = instance;

      switch (config.clickAction) {
        case 'highlight':
          if (object.material) {
            const newMat = object.material.clone();
            newMat.emissive = new THREE.Color(config.highlightColor);
            newMat.emissiveIntensity = 1;
            object.material = newMat;
          }
          break;

        case 'focus':
          if (instance.controls) {
            const box = new THREE.Box3().setFromObject(object);
            const center = box.getCenter(new THREE.Vector3());
            instance.controls.target.copy(center);
          }
          break;
      }
    },

    /**
     * Setup scroll animation
     */
    setupScrollAnimation: function(instance) {
      const { wrapper, config } = instance;

      // Parse trigger positions (supports vh, px, %, or element positions like "top center")
      const parseTriggerValue = (value, elementRect, viewportHeight) => {
        if (typeof value === 'string') {
          // Handle vh values
          if (value.endsWith('vh')) {
            return parseFloat(value) / 100 * viewportHeight;
          }
          // Handle percentage
          if (value.endsWith('%')) {
            return parseFloat(value) / 100 * elementRect.height;
          }
          // Handle px values
          if (value.endsWith('px')) {
            return parseFloat(value);
          }
          // Handle element position format like "top center", "bottom top"
          const parts = value.split(' ');
          if (parts.length >= 2) {
            let elementPos = 0;
            let viewportPos = 0;
            // Element position
            if (parts[0] === 'top') elementPos = elementRect.top;
            else if (parts[0] === 'center') elementPos = elementRect.top + elementRect.height / 2;
            else if (parts[0] === 'bottom') elementPos = elementRect.bottom;
            // Viewport position
            if (parts[1] === 'top') viewportPos = 0;
            else if (parts[1] === 'center') viewportPos = viewportHeight / 2;
            else if (parts[1] === 'bottom') viewportPos = viewportHeight;
            return elementPos - viewportPos;
          }
        }
        return parseFloat(value) || 0;
      };

      let scrollStart = 0;
      let scrollEnd = 0;
      let pinOffset = 0;
      let isPinned = false;
      let debugMarkers = null;
      let pinSpacer = null;
      let originalStyles = null;
      let wrapperRect = null;
      let originalWrapperTop = null; // Store the original document position

      // Parse pin offset to pixels for scroll calculations
      const parsePinOffsetToPixels = (offsetValue) => {
        if (!offsetValue || offsetValue === '0' || offsetValue === '0px') return 0;
        const str = String(offsetValue).trim();
        const viewportHeight = window.innerHeight;

        if (str.endsWith('vh')) {
          return (parseFloat(str) / 100) * viewportHeight;
        } else if (str.endsWith('%')) {
          return (parseFloat(str) / 100) * viewportHeight;
        } else if (str.endsWith('px')) {
          return parseFloat(str);
        } else {
          return parseFloat(str) || 0;
        }
      };

      const updateScrollBounds = () => {
        const viewportHeight = window.innerHeight;
        const scrollTop = window.pageYOffset;

        // Use spacer position if pinned (it maintains original position), otherwise use wrapper
        let rect;
        if (isPinned && pinSpacer) {
          rect = pinSpacer.getBoundingClientRect();
        } else {
          rect = wrapper.getBoundingClientRect();
          // Store original position on first calculation
          if (originalWrapperTop === null) {
            originalWrapperTop = scrollTop + rect.top;
          }
        }

        // Get pin offset in pixels for scroll calculation adjustment
        const pinOffsetPx = config.scrollPin ? parsePinOffsetToPixels(config.scrollPinOffset) : 0;

        // Calculate start trigger position, adjusted for pin offset
        // When pin offset is set, the trigger should fire earlier to account for the offset
        scrollStart = scrollTop + parseTriggerValue(config.scrollTriggerStart, rect, viewportHeight) - pinOffsetPx;

        // Calculate end trigger position
        // If end is a vh/px/% value (not element position like "bottom center"),
        // treat it as a distance from scroll start
        const endValue = config.scrollTriggerEnd;
        if (typeof endValue === 'string' && (endValue.endsWith('vh') || endValue.endsWith('px') || endValue.endsWith('%'))) {
          // It's a distance value - add to scrollStart
          scrollEnd = scrollStart + parseTriggerValue(endValue, rect, viewportHeight);
        } else {
          // It's an element position - calculate normally
          scrollEnd = scrollTop + parseTriggerValue(endValue, rect, viewportHeight) - pinOffsetPx;
        }

        // Ensure scrollEnd is after scrollStart
        if (scrollEnd <= scrollStart) {
          scrollEnd = scrollStart + rect.height;
        }
      };

      updateScrollBounds();
      window.addEventListener('resize', updateScrollBounds);

      // Add debug markers if enabled
      if (config.scrollDebug) {
        debugMarkers = document.createElement('div');
        debugMarkers.innerHTML = `
          <div style="position:fixed;left:0;right:0;height:2px;background:#00ff00;z-index:9999;pointer-events:none;" id="scroll-start-marker"></div>
          <div style="position:fixed;left:0;right:0;height:2px;background:#ff0000;z-index:9999;pointer-events:none;" id="scroll-end-marker"></div>
          <div style="position:fixed;top:10px;right:10px;background:rgba(0,0,0,0.8);color:#fff;padding:10px;font-size:12px;font-family:monospace;z-index:9999;" id="scroll-debug-info"></div>
        `;
        document.body.appendChild(debugMarkers);
      }

      // Process scroll keyframes
      const processedScrollKeyframes = config.scrollKeyframes.map(kf => ({
        scrollPosition: parseFloat(kf.scroll_position) || 0,
        positionX: parseFloat(kf.position_x) || 0,
        positionY: parseFloat(kf.position_y) || 0,
        positionZ: parseFloat(kf.position_z) || 0,
        rotationX: parseFloat(kf.rotation_x) || 0,
        rotationY: parseFloat(kf.rotation_y) || 0,
        rotationZ: parseFloat(kf.rotation_z) || 0,
        scale: parseFloat(kf.scale) || 1,
        opacity: parseFloat(kf.opacity) !== undefined ? parseFloat(kf.opacity) : 1,
        // Camera position support
        cameraX: kf.camera_x !== undefined && kf.camera_x !== '' ? parseFloat(kf.camera_x) : null,
        cameraY: kf.camera_y !== undefined && kf.camera_y !== '' ? parseFloat(kf.camera_y) : null,
        cameraZ: kf.camera_z !== undefined && kf.camera_z !== '' ? parseFloat(kf.camera_z) : null,
        // Camera target (look at) support
        cameraTargetX: kf.camera_target_x !== undefined && kf.camera_target_x !== '' ? parseFloat(kf.camera_target_x) : null,
        cameraTargetY: kf.camera_target_y !== undefined && kf.camera_target_y !== '' ? parseFloat(kf.camera_target_y) : null,
        cameraTargetZ: kf.camera_target_z !== undefined && kf.camera_target_z !== '' ? parseFloat(kf.camera_target_z) : null,
        easing: kf.easing || 'linear',
        label: kf.label || ''
      })).sort((a, b) => a.scrollPosition - b.scrollPosition);

      // Store for use in animate loop when scrubbing
      instance.scrollAnimation = {
        keyframes: processedScrollKeyframes,
        progress: 0,
        isActive: false
      };

      const interpolateValue = (start, end, t, easing) => {
        const easedT = this.applyEasing(t, easing);
        return start + (end - start) * easedT;
      };

      const getKeyframeValues = (progress) => {
        if (processedScrollKeyframes.length === 0) return null;

        // Find surrounding keyframes
        let prevKf = null;
        let nextKf = null;

        for (let i = 0; i < processedScrollKeyframes.length; i++) {
          if (processedScrollKeyframes[i].scrollPosition <= progress) {
            prevKf = processedScrollKeyframes[i];
          }
          if (processedScrollKeyframes[i].scrollPosition > progress && !nextKf) {
            nextKf = processedScrollKeyframes[i];
            break;
          }
        }

        // If no previous keyframe, use first
        if (!prevKf && processedScrollKeyframes.length > 0) {
          prevKf = processedScrollKeyframes[0];
        }

        // If no next keyframe, use last or return prev values
        if (!nextKf) {
          if (prevKf) {
            return {
              positionX: prevKf.positionX,
              positionY: prevKf.positionY,
              positionZ: prevKf.positionZ,
              rotationX: prevKf.rotationX,
              rotationY: prevKf.rotationY,
              rotationZ: prevKf.rotationZ,
              scale: prevKf.scale,
              opacity: prevKf.opacity,
              cameraX: prevKf.cameraX,
              cameraY: prevKf.cameraY,
              cameraZ: prevKf.cameraZ,
              cameraTargetX: prevKf.cameraTargetX,
              cameraTargetY: prevKf.cameraTargetY,
              cameraTargetZ: prevKf.cameraTargetZ
            };
          }
          return null;
        }

        // Interpolate between keyframes
        const range = nextKf.scrollPosition - prevKf.scrollPosition;
        const t = range > 0 ? (progress - prevKf.scrollPosition) / range : 0;

        return {
          positionX: interpolateValue(prevKf.positionX, nextKf.positionX, t, nextKf.easing),
          positionY: interpolateValue(prevKf.positionY, nextKf.positionY, t, nextKf.easing),
          positionZ: interpolateValue(prevKf.positionZ, nextKf.positionZ, t, nextKf.easing),
          rotationX: interpolateValue(prevKf.rotationX, nextKf.rotationX, t, nextKf.easing),
          rotationY: interpolateValue(prevKf.rotationY, nextKf.rotationY, t, nextKf.easing),
          rotationZ: interpolateValue(prevKf.rotationZ, nextKf.rotationZ, t, nextKf.easing),
          scale: interpolateValue(prevKf.scale, nextKf.scale, t, nextKf.easing),
          opacity: interpolateValue(prevKf.opacity, nextKf.opacity, t, nextKf.easing),
          cameraX: prevKf.cameraX !== null && nextKf.cameraX !== null ? interpolateValue(prevKf.cameraX, nextKf.cameraX, t, nextKf.easing) : null,
          cameraY: prevKf.cameraY !== null && nextKf.cameraY !== null ? interpolateValue(prevKf.cameraY, nextKf.cameraY, t, nextKf.easing) : null,
          cameraZ: prevKf.cameraZ !== null && nextKf.cameraZ !== null ? interpolateValue(prevKf.cameraZ, nextKf.cameraZ, t, nextKf.easing) : null,
          cameraTargetX: prevKf.cameraTargetX !== null && nextKf.cameraTargetX !== null ? interpolateValue(prevKf.cameraTargetX, nextKf.cameraTargetX, t, nextKf.easing) : null,
          cameraTargetY: prevKf.cameraTargetY !== null && nextKf.cameraTargetY !== null ? interpolateValue(prevKf.cameraTargetY, nextKf.cameraTargetY, t, nextKf.easing) : null,
          cameraTargetZ: prevKf.cameraTargetZ !== null && nextKf.cameraTargetZ !== null ? interpolateValue(prevKf.cameraTargetZ, nextKf.cameraTargetZ, t, nextKf.easing) : null
        };
      };

      const onScroll = () => {
        if (!instance.model || !instance.initialModelPosition) return;

        const scrollY = window.pageYOffset;
        const range = scrollEnd - scrollStart;

        // Calculate raw progress (unclamped) for pinning logic
        const rawProgress = range > 0 ? (scrollY - scrollStart) / range : 0;

        // Clamp progress for animation values
        let progress = Math.max(0, Math.min(1, rawProgress));

        // Store progress for debugging
        instance.scrollAnimation.progress = progress;
        instance.scrollAnimation.isActive = rawProgress >= 0 && rawProgress <= 1;

        // Update debug markers
        if (config.scrollDebug && debugMarkers) {
          const viewportHeight = window.innerHeight;
          const startMarker = debugMarkers.querySelector('#scroll-start-marker');
          const endMarker = debugMarkers.querySelector('#scroll-end-marker');
          const debugInfo = debugMarkers.querySelector('#scroll-debug-info');

          if (startMarker) startMarker.style.top = (scrollStart - scrollY) + 'px';
          if (endMarker) endMarker.style.top = (scrollEnd - scrollY) + 'px';
          if (debugInfo) debugInfo.textContent = `Progress: ${(progress * 100).toFixed(1)}%\nRaw: ${(rawProgress * 100).toFixed(1)}%\nScroll: ${scrollY}px\nStart: ${scrollStart.toFixed(0)}px\nEnd: ${scrollEnd.toFixed(0)}px\nPinned: ${isPinned}`;
        }

        // Handle pinning with proper spacer element
        // Pin when scroll is at or past the start trigger and before the end trigger
        if (config.scrollPin) {
          const shouldPin = rawProgress >= 0 && rawProgress < 1;

          // Parse pin offset - supports px, vh, %, or plain numbers (treated as px)
          const parsePinOffset = (offsetValue) => {
            if (!offsetValue || offsetValue === '0' || offsetValue === '0px') return '0px';
            const str = String(offsetValue).trim();
            // If it's just a number, treat as pixels
            if (/^-?\d+(\.\d+)?$/.test(str)) {
              return str + 'px';
            }
            // Otherwise return as-is (supports px, vh, %, em, rem, etc.)
            return str;
          };

          const pinTopOffset = parsePinOffset(config.scrollPinOffset);

          if (shouldPin && !isPinned) {
            // Store original dimensions and position before pinning
            wrapperRect = wrapper.getBoundingClientRect();
            originalStyles = {
              position: wrapper.style.position,
              top: wrapper.style.top,
              left: wrapper.style.left,
              width: wrapper.style.width,
              height: wrapper.style.height,
              zIndex: wrapper.style.zIndex
            };

            // Calculate spacer height: the scroll distance for the full animation
            // This is scrollEnd - scrollStart (the range the user needs to scroll)
            const scrollDistance = scrollEnd - scrollStart;
            const spacerHeight = Math.max(wrapperRect.height, scrollDistance + wrapperRect.height);

            // Create spacer to maintain scroll height (or resize existing one)
            if (!pinSpacer) {
              pinSpacer = document.createElement('div');
              pinSpacer.className = 'model-viewer-pin-spacer';
              wrapper.parentNode.insertBefore(pinSpacer, wrapper);
            }
            pinSpacer.style.cssText = `
              width: ${wrapperRect.width}px;
              height: ${spacerHeight}px;
              flex-shrink: 0;
              pointer-events: none;
            `;

            // Pin the wrapper with dynamic top offset
            isPinned = true;
            wrapper.style.position = 'fixed';
            wrapper.style.top = pinTopOffset;
            wrapper.style.left = wrapperRect.left + 'px';
            wrapper.style.width = wrapperRect.width + 'px';
            wrapper.style.height = wrapperRect.height + 'px';
            wrapper.style.zIndex = '1000';

          } else if (!shouldPin && isPinned) {
            // Unpin the wrapper
            isPinned = false;

            // Restore original styles
            if (originalStyles) {
              wrapper.style.position = originalStyles.position;
              wrapper.style.top = originalStyles.top;
              wrapper.style.left = originalStyles.left;
              wrapper.style.width = originalStyles.width;
              wrapper.style.height = originalStyles.height;
              wrapper.style.zIndex = originalStyles.zIndex;
              originalStyles = null;
            }

            // Handle spacer based on whether we're before or after the animation
            if (pinSpacer && pinSpacer.parentNode) {
              if (rawProgress >= 1) {
                // Animation ended - keep spacer but shrink it to just padding
                // This prevents page jump when animation completes
                const scrollDistance = scrollEnd - scrollStart;
                pinSpacer.style.height = scrollDistance + 'px';
                // Move wrapper after spacer so it's at the end position
                if (pinSpacer.nextSibling !== wrapper) {
                  pinSpacer.parentNode.insertBefore(wrapper, pinSpacer.nextSibling);
                }
              } else {
                // Scrolled back before animation - remove spacer entirely
                pinSpacer.parentNode.removeChild(pinSpacer);
                pinSpacer = null;
              }
            }
          }
        }

        // Apply keyframe-based animation if keyframes exist
        if (processedScrollKeyframes.length > 0 && config.scrollScrub) {
          const values = getKeyframeValues(progress * 100); // Convert to percentage
          if (values) {
            const newModelX = instance.initialModelPosition.x + values.positionX;
            const newModelY = instance.initialModelPosition.y + values.positionY;
            const newModelZ = instance.initialModelPosition.z + values.positionZ;

            instance.model.position.set(newModelX, newModelY, newModelZ);
            instance.model.rotation.set(
              instance.initialModelRotation.x + (values.rotationX * Math.PI / 180),
              instance.initialModelRotation.y + (values.rotationY * Math.PI / 180),
              instance.initialModelRotation.z + (values.rotationZ * Math.PI / 180)
            );
            const scale = instance.config.modelScale * values.scale;

            // Move shadow ground and light to follow model (X and Z position)
            if (instance.shadowGround) {
              instance.shadowGround.position.x = newModelX;
              instance.shadowGround.position.z = newModelZ;
            }

            // Move directional light to follow model for consistent shadows
            if (instance.directionalLight && instance.directionalLightBasePosition) {
              instance.directionalLight.position.x = instance.directionalLightBasePosition.x + newModelX;
              instance.directionalLight.position.z = instance.directionalLightBasePosition.z + newModelZ;
              // Update shadow camera to look at new model position
              instance.directionalLight.target.position.set(newModelX, 0, newModelZ);
              instance.directionalLight.target.updateMatrixWorld();
            }

            instance.model.scale.setScalar(scale);

            // Apply opacity to all meshes
            if (values.opacity !== undefined) {
              instance.model.traverse((child) => {
                if (child.material) {
                  if (!child.material._originalOpacity) {
                    child.material._originalOpacity = child.material.opacity;
                  }
                  child.material.opacity = child.material._originalOpacity * values.opacity;
                  child.material.transparent = values.opacity < 1;
                }
              });
            }

            // Apply camera position changes
            const hasCameraPosition = values.cameraX !== null || values.cameraY !== null || values.cameraZ !== null;
            const hasCameraTarget = values.cameraTargetX !== null || values.cameraTargetY !== null || values.cameraTargetZ !== null;

            if (hasCameraPosition) {
              if (values.cameraX !== null) instance.camera.position.x = values.cameraX;
              if (values.cameraY !== null) instance.camera.position.y = values.cameraY;
              if (values.cameraZ !== null) instance.camera.position.z = values.cameraZ;
            }

            // Apply camera target (look at) changes
            if (hasCameraTarget) {
              const targetX = values.cameraTargetX !== null ? values.cameraTargetX : instance.controls.target.x;
              const targetY = values.cameraTargetY !== null ? values.cameraTargetY : instance.controls.target.y;
              const targetZ = values.cameraTargetZ !== null ? values.cameraTargetZ : instance.controls.target.z;
              instance.camera.lookAt(targetX, targetY, targetZ);
              // Update controls target to match
              instance.controls.target.set(targetX, targetY, targetZ);
            } else if (hasCameraPosition) {
              // If only position changed, look at existing target
              instance.camera.lookAt(instance.controls.target);
            }

            // Update controls if camera changed
            if (hasCameraPosition || hasCameraTarget) {
              instance.controls.update();
            }
          }
        } else {
          // Legacy simple scroll animation
          switch (config.scrollAnimationType) {
            case 'rotate':
              instance.model.rotation.y = instance.initialModelRotation.y + progress * Math.PI * 2 * config.scrollSpeed;
              break;
            case 'zoom':
              const baseScale = instance.config.modelScale;
              const scale = baseScale + progress * config.scrollSpeed;
              instance.model.scale.setScalar(scale);
              break;
            case 'position':
              instance.model.position.y = instance.initialModelPosition.y + progress * 5 * config.scrollSpeed;
              break;
          }
        }
      };

      window.addEventListener('scroll', onScroll);

      // Store cleanup function for destroy
      instance.scrollAnimationCleanup = () => {
        window.removeEventListener('scroll', onScroll);
        window.removeEventListener('resize', updateScrollBounds);
        if (debugMarkers && debugMarkers.parentNode) {
          debugMarkers.parentNode.removeChild(debugMarkers);
        }
        // Clean up pin spacer
        if (pinSpacer && pinSpacer.parentNode) {
          pinSpacer.parentNode.removeChild(pinSpacer);
        }
        // Restore wrapper styles if still pinned
        if (isPinned && originalStyles) {
          wrapper.style.position = originalStyles.position;
          wrapper.style.top = originalStyles.top;
          wrapper.style.left = originalStyles.left;
          wrapper.style.width = originalStyles.width;
          wrapper.style.height = originalStyles.height;
          wrapper.style.zIndex = originalStyles.zIndex;
        }
      };

      // Initial call to set up state
      onScroll();
    },

    /**
     * Setup FPS stats
     */
    setupStats: function(instance) {
      // Simple FPS counter
      const statsDiv = document.createElement('div');
      statsDiv.style.cssText = 'position:absolute;top:10px;left:10px;background:rgba(0,0,0,0.7);color:#fff;padding:5px 10px;font-size:12px;font-family:monospace;z-index:100;';
      instance.wrapper.appendChild(statsDiv);

      instance.stats = {
        element: statsDiv,
        frames: 0,
        lastTime: performance.now()
      };
    },

    /**
     * Update FPS stats
     */
    updateStats: function(instance) {
      if (!instance.stats) return;

      instance.stats.frames++;
      const now = performance.now();

      if (now - instance.stats.lastTime >= 1000) {
        const fps = Math.round(instance.stats.frames * 1000 / (now - instance.stats.lastTime));
        instance.stats.element.textContent = `FPS: ${fps}`;
        instance.stats.frames = 0;
        instance.stats.lastTime = now;
      }
    },

    /**
     * Load 3D model based on type
     */
    loadModel: function(instance) {
      const { config } = instance;
      this.showLoading(instance);

      switch (config.modelType) {
        case 'gltf':
          this.loadGLTF(instance);
          break;
        case 'fbx':
          this.loadFBX(instance);
          break;
        case 'obj':
          this.loadOBJ(instance);
          break;
        default:
          this.showError(instance, 'Unsupported model type: ' + config.modelType);
      }
    },

    /**
     * Load GLTF/GLB model
     */
    loadGLTF: function(instance) {
      this.waitForLoader('GLTFLoader', () => {
        const loader = new THREE.GLTFLoader();
        loader.load(
          instance.config.modelUrl,
          (gltf) => {
            this.onModelLoaded(instance, gltf.scene, gltf.animations);
          },
          (progress) => this.onProgress(instance, progress),
          (error) => this.showError(instance, 'Failed to load GLTF model: ' + error.message)
        );
      });
    },

    /**
     * Load FBX model
     */
    loadFBX: function(instance) {
      this.waitForLoader('FBXLoader', () => {
        const loader = new THREE.FBXLoader();
        loader.load(
          instance.config.modelUrl,
          (fbx) => {
            this.onModelLoaded(instance, fbx, fbx.animations);
          },
          (progress) => this.onProgress(instance, progress),
          (error) => this.showError(instance, 'Failed to load FBX model: ' + error.message)
        );
      });
    },

    /**
     * Load OBJ model
     */
    loadOBJ: function(instance) {
      this.waitForLoader('OBJLoader', () => {
        const loader = new THREE.OBJLoader();
        loader.load(
          instance.config.modelUrl,
          (obj) => {
            if (instance.config.textureUrl) {
              const textureLoader = new THREE.TextureLoader();
              textureLoader.load(instance.config.textureUrl, (texture) => {
                obj.traverse((child) => {
                  if (child instanceof THREE.Mesh) {
                    child.material.map = texture;
                    child.material.needsUpdate = true;
                  }
                });
              });
            }
            this.onModelLoaded(instance, obj);
          },
          (progress) => this.onProgress(instance, progress),
          (error) => this.showError(instance, 'Failed to load OBJ model: ' + error.message)
        );
      });
    },

    /**
     * Wait for a specific loader
     */
    waitForLoader: function(loaderName, callback, attempts = 0) {
      if (THREE[loaderName]) {
        callback();
      } else if (attempts < 50) {
        setTimeout(() => this.waitForLoader(loaderName, callback, attempts + 1), 100);
      } else {
        console.error(loaderName + ' not loaded after 5 seconds');
      }
    },

    /**
     * Handle model loaded
     */
    onModelLoaded: function(instance, model, animations) {
      if (instance.model) {
        instance.scene.remove(instance.model);
      }

      // Apply scale
      model.scale.setScalar(instance.config.modelScale);

      // Enable shadows and apply materials
      model.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          if (instance.config.enableShadows) {
            child.castShadow = true;
            child.receiveShadow = true;
          }
          if (instance.config.enableColorOverride && child.material) {
            child.material.color = new THREE.Color(instance.config.modelColor);
            child.material.metalness = instance.config.metalness;
            child.material.roughness = instance.config.roughness;
            child.material.emissive = new THREE.Color(instance.config.emissive);
            child.material.emissiveIntensity = instance.config.emissiveIntensity;
            child.material.needsUpdate = true;
          }
        }
      });

      // Auto-fit model to viewport if enabled
      if (instance.config.autoFit) {
        const box = new THREE.Box3().setFromObject(model);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);

        // Target size of about 2-3 units
        const targetSize = 2.5;
        if (maxDim > 0) {
          const autoScale = targetSize / maxDim;
          model.scale.multiplyScalar(autoScale);
        }
      }

      // Center the model (optional)
      if (instance.config.centerModel) {
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        model.position.sub(center);

        // Also lift model so it sits on ground plane (y=0) if needed
        const newBox = new THREE.Box3().setFromObject(model);
        if (newBox.min.y < 0) {
          model.position.y -= newBox.min.y;
        }
      }

      // Apply initial position
      model.position.x += instance.config.initialPositionX;
      model.position.y += instance.config.initialPositionY;
      model.position.z += instance.config.initialPositionZ;

      // Apply initial rotation (convert degrees to radians)
      model.rotation.x += (instance.config.initialRotationX * Math.PI) / 180;
      model.rotation.y += (instance.config.initialRotationY * Math.PI) / 180;
      model.rotation.z += (instance.config.initialRotationZ * Math.PI) / 180;

      instance.scene.add(model);
      instance.model = model;
      instance.initialModelPosition = model.position.clone();
      instance.initialModelScale = model.scale.clone();
      instance.initialModelRotation = model.rotation.clone();

      // Create model instances if enabled
      if (instance.config.enableInstances && instance.config.instances.length > 0) {
        this.createModelInstances(instance, model);
      }

      // Setup animations
      if (animations && animations.length > 0) {
        instance.animations = animations;
      }
      if (instance.config.enableAnimations) {
        this.setupAnimations(instance, model);
      }

      this.hideLoading(instance);
      instance.isLoaded = true;

      // Trigger scroll event to apply initial keyframe position
      // This ensures the model starts at the correct position based on scroll keyframes
      if (instance.config.enableScrollAnimation && instance.config.scrollKeyframes.length > 0) {
        window.dispatchEvent(new Event('scroll'));
      }
    },

    /**
     * Create model instances (clones)
     */
    createModelInstances: function(instance, model) {
      instance.config.instances.forEach((instData) => {
        if (instData.visible === false) return;

        const clone = model.clone();

        clone.position.set(
          parseFloat(instData.position_x) || 0,
          parseFloat(instData.position_y) || 0,
          parseFloat(instData.position_z) || 0
        );

        clone.rotation.set(
          (parseFloat(instData.rotation_x) || 0) * Math.PI / 180,
          (parseFloat(instData.rotation_y) || 0) * Math.PI / 180,
          (parseFloat(instData.rotation_z) || 0) * Math.PI / 180
        );

        const scale = parseFloat(instData.scale) || 1;
        clone.scale.setScalar(instance.config.modelScale * scale);

        // Apply color override if set
        if (instData.override_color && instData.color) {
          clone.traverse((child) => {
            if (child instanceof THREE.Mesh && child.material) {
              child.material = child.material.clone();
              child.material.color = new THREE.Color(this.stripAlpha(instData.color));
            }
          });
        }

        instance.scene.add(clone);
        instance.modelInstances.push(clone);
      });
    },

    /**
     * Handle loading progress
     */
    onProgress: function(instance, progress) {
      if (progress.lengthComputable) {
        const percentComplete = (progress.loaded / progress.total) * 100;
        const loadingText = instance.wrapper.querySelector('.loading-text');
        if (loadingText) {
          loadingText.textContent = 'Loading 3D Model... ' + Math.round(percentComplete) + '%';
        }
      }
    },

    /**
     * Setup animations
     */
    setupAnimations: function(instance, model) {
      const { config } = instance;

      if (config.animationType === 'custom' || config.animationType === 'timeline') {
        if (config.animationType === 'timeline') {
          instance.processedKeyframes = this.processKeyframes(
            config.positionKeyframes,
            config.rotationKeyframes,
            config.scaleKeyframes
          );
          instance.duration = config.timelineDuration;
        }
        if (config.autoPlay) instance.isPlaying = true;
        return;
      }

      // Model animations
      if (instance.animations && instance.animations.length > 0) {
        instance.mixer = new THREE.AnimationMixer(model);

        const clips = instance.animations;
        let clipsToPlay = [];

        if (config.selectedAnimation === 'all') {
          clipsToPlay = clips;
        } else if (config.selectedAnimation === 'first' && clips.length > 0) {
          clipsToPlay = [clips[0]];
        } else if (config.selectedAnimation === 'by_index') {
          const index = Math.min(config.animationIndex, clips.length - 1);
          if (clips[index]) clipsToPlay = [clips[index]];
        }

        clipsToPlay.forEach((clip) => {
          const action = instance.mixer.clipAction(clip);
          action.setLoop(config.loop ? THREE.LoopRepeat : THREE.LoopOnce);
          action.timeScale = config.animationSpeed;
          instance.activeActions.push(action);
          if (config.autoPlay) {
            action.play();
            instance.isPlaying = true;
          }
        });

        if (instance.activeActions.length > 0) {
          instance.duration = instance.activeActions[0].getClip().duration;
        }
      }
    },

    /**
     * Process keyframes
     */
    processKeyframes: function(positionKeyframes, rotationKeyframes, scaleKeyframes) {
      const all = [];

      if (positionKeyframes) {
        positionKeyframes.forEach(kf => {
          all.push({
            time: parseFloat(kf.time) || 0,
            property: 'position',
            x: parseFloat(kf.x) || 0,
            y: parseFloat(kf.y) || 0,
            z: parseFloat(kf.z) || 0,
            easing: kf.easing || 'linear'
          });
        });
      }

      if (rotationKeyframes) {
        rotationKeyframes.forEach(kf => {
          all.push({
            time: parseFloat(kf.time) || 0,
            property: 'rotation',
            x: (parseFloat(kf.x) || 0) * Math.PI / 180,
            y: (parseFloat(kf.y) || 0) * Math.PI / 180,
            z: (parseFloat(kf.z) || 0) * Math.PI / 180,
            easing: kf.easing || 'linear'
          });
        });
      }

      if (scaleKeyframes) {
        scaleKeyframes.forEach(kf => {
          all.push({
            time: parseFloat(kf.time) || 0,
            property: 'scale',
            x: parseFloat(kf.x) || 1,
            y: parseFloat(kf.y) || 1,
            z: parseFloat(kf.z) || 1,
            easing: kf.easing || 'linear'
          });
        });
      }

      return all.sort((a, b) => a.time - b.time);
    },

    /**
     * Animation loop
     */
    animate: function(instance) {
      const config = instance.config;

      // FPS limiting
      if (config.maxFps > 0) {
        const interval = 1000 / config.maxFps;
        if (!instance.lastFrameTime) instance.lastFrameTime = 0;
        const now = performance.now();
        if (now - instance.lastFrameTime < interval) {
          instance.animationId = requestAnimationFrame(() => this.animate(instance));
          return;
        }
        instance.lastFrameTime = now;
      }

      instance.animationId = requestAnimationFrame(() => this.animate(instance));

      const delta = instance.clock.getDelta();

      // Update mixer
      if (instance.mixer) {
        instance.mixer.update(delta);
      }

      // Update physics
      if (config.enablePhysics) {
        this.updatePhysics(instance, delta);
      }

      // Update custom/timeline animations
      if (config.enableAnimations && instance.isPlaying && instance.model) {
        instance.customAnimationTime += delta * config.animationSpeed;

        if (config.animationType === 'timeline') {
          if (config.loop && instance.customAnimationTime >= instance.duration) {
            instance.customAnimationTime = 0;
          }
          this.applyTimelineAnimation(instance);
        } else if (config.animationType === 'custom') {
          if (config.customRotation) {
            const speed = 2 * config.animationSpeed;
            if (config.rotationAxis === 'y' || config.rotationAxis === 'all') instance.model.rotation.y += delta * speed;
            if (config.rotationAxis === 'x' || config.rotationAxis === 'all') instance.model.rotation.x += delta * speed;
            if (config.rotationAxis === 'z' || config.rotationAxis === 'all') instance.model.rotation.z += delta * speed;
          }
          if (config.customBounce && instance.initialModelPosition) {
            const offset = Math.sin(instance.customAnimationTime * 2) * config.bounceHeight;
            instance.model.position.y = instance.initialModelPosition.y + offset;
          }
          if (config.customScalePulse && instance.initialModelScale) {
            const scale = 1 + Math.sin(instance.customAnimationTime * 2) * config.scaleAmount;
            instance.model.scale.set(
              instance.initialModelScale.x * scale,
              instance.initialModelScale.y * scale,
              instance.initialModelScale.z * scale
            );
          }
        }
      }

      // Update particle systems
      if (instance.particleSystems.length > 0) {
        this.updateParticleSystems(instance, delta);
      }

      // Apply mouse tracking (should happen after other animations to override them when hovering)
      if (config.enableMouseTracking && instance.mouseTracking && instance.mouseTracking.isHovering) {
        this.applyMouseTracking(instance);
      }

      if (instance.controls) {
        instance.controls.update();
      }

      // Update stats
      if (config.enableStats) {
        this.updateStats(instance);
      }

      if (instance.renderer && instance.scene && instance.camera) {
        instance.renderer.render(instance.scene, instance.camera);
      }
    },

    /**
     * Apply timeline animation
     */
    applyTimelineAnimation: function(instance) {
      if (!instance.processedKeyframes || !instance.model) return;

      const currentTime = instance.customAnimationTime % instance.duration;
      const kfs = instance.processedKeyframes;

      ['position', 'rotation', 'scale'].forEach((prop) => {
        const propKfs = kfs.filter(k => k.property === prop);
        if (propKfs.length === 0) return;

        const interp = this.interpolateKeyframes(propKfs, currentTime);
        if (!interp) return;

        if (prop === 'position') {
          instance.model.position.set(
            instance.initialModelPosition.x + interp.x,
            instance.initialModelPosition.y + interp.y,
            instance.initialModelPosition.z + interp.z
          );
        } else if (prop === 'rotation') {
          instance.model.rotation.set(
            instance.initialModelRotation.x + interp.x,
            instance.initialModelRotation.y + interp.y,
            instance.initialModelRotation.z + interp.z
          );
        } else if (prop === 'scale') {
          instance.model.scale.set(
            instance.initialModelScale.x * interp.x,
            instance.initialModelScale.y * interp.y,
            instance.initialModelScale.z * interp.z
          );
        }
      });
    },

    /**
     * Interpolate keyframes
     */
    interpolateKeyframes: function(keyframes, time) {
      if (keyframes.length === 0) return null;

      let prev = null, next = null;
      for (let i = 0; i < keyframes.length; i++) {
        if (keyframes[i].time <= time) prev = keyframes[i];
        if (keyframes[i].time > time && !next) { next = keyframes[i]; break; }
      }

      if (prev && next) {
        const t = (time - prev.time) / (next.time - prev.time);
        const et = this.applyEasing(t, next.easing);
        return {
          x: prev.x + (next.x - prev.x) * et,
          y: prev.y + (next.y - prev.y) * et,
          z: prev.z + (next.z - prev.z) * et
        };
      }

      if (prev) return { x: prev.x, y: prev.y, z: prev.z };
      return null;
    },

    /**
     * Apply easing
     */
    applyEasing: function(t, easing) {
      switch (easing) {
        case 'easeIn': return t * t;
        case 'easeOut': return t * (2 - t);
        case 'easeInOut': return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        case 'power3In': return t * t * t;
        case 'power3Out': return (--t) * t * t + 1;
        case 'elasticOut':
          const c = (2 * Math.PI) / 3;
          return t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c) + 1;
        case 'bounceOut':
          const n = 7.5625, d = 2.75;
          if (t < 1/d) return n*t*t;
          if (t < 2/d) return n*(t-=1.5/d)*t+0.75;
          if (t < 2.5/d) return n*(t-=2.25/d)*t+0.9375;
          return n*(t-=2.625/d)*t+0.984375;
        default: return t;
      }
    },

    /**
     * Handle window resize
     */
    onResize: function(instance) {
      if (!instance.camera || !instance.renderer || !instance.canvasContainer) return;
      const width = instance.canvasContainer.clientWidth;
      const height = instance.canvasContainer.clientHeight;
      const config = instance.config;

      if (instance.camera.isOrthographicCamera) {
        const aspect = width / height;
        const zoom = config.orthoZoom;
        instance.camera.left = -zoom * aspect;
        instance.camera.right = zoom * aspect;
        instance.camera.top = zoom;
        instance.camera.bottom = -zoom;
      } else {
        instance.camera.aspect = width / height;
      }
      instance.camera.updateProjectionMatrix();
      instance.renderer.setSize(width, height);
    },

    /**
     * Show loading state
     */
    showLoading: function(instance) {
      const loading = instance.wrapper.querySelector('.model-viewer-loading');
      if (loading) loading.style.display = 'flex';
    },

    /**
     * Hide loading state
     */
    hideLoading: function(instance) {
      instance.wrapper.classList.add('loaded');
      setTimeout(() => {
        const loading = instance.wrapper.querySelector('.model-viewer-loading');
        if (loading) loading.style.display = 'none';
      }, 300);
    },

    /**
     * Show error state
     */
    showError: function(instance, message) {
      console.error('Model Viewer Error:', message);
      const loading = instance.wrapper.querySelector('.model-viewer-loading');
      const error = instance.wrapper.querySelector('.model-viewer-error');
      if (loading) loading.style.display = 'none';
      if (error) {
        const errorText = error.querySelector('.error-text');
        if (errorText) errorText.textContent = message;
        error.style.display = 'flex';
      }
    },

    /**
     * Update instance configuration - full reinit for builder compatibility
     */
    update: function(id) {
      const instance = this.instances[id];
      if (!instance) return;

      // Use stored selector from init
      const selector = instance.selector;
      if (!selector) return;

      // Destroy the current instance
      this.destroy(id);

      // Small delay to ensure cleanup is complete, then reinitialize
      setTimeout(() => {
        this.init(selector, id);
      }, 100);
    },

    /**
     * Destroy instance
     */
    destroy: function(id) {
      const instance = this.instances[id];
      if (!instance) return;

      // Cancel animation frame
      if (instance.animationId) cancelAnimationFrame(instance.animationId);

      // Clean up mouse tracking listeners
      if (instance.mouseTracking && instance.mouseTracking.cleanup) instance.mouseTracking.cleanup();

      // Clean up scroll animation cleanup function if stored
      if (instance.scrollAnimationCleanup) instance.scrollAnimationCleanup();

      // Clean up resize listener
      if (instance.resizeHandler) {
        window.removeEventListener('resize', instance.resizeHandler);
      }

      // Remove debug markers if they exist
      const debugMarkers = document.querySelectorAll('#scroll-start-marker, #scroll-end-marker, #scroll-debug-info');
      debugMarkers.forEach(marker => {
        if (marker.parentNode) marker.parentNode.removeChild(marker);
      });

      // Dispose renderer
      if (instance.renderer) {
        instance.renderer.dispose();
        if (instance.renderer.domElement && instance.renderer.domElement.parentNode) {
          instance.renderer.domElement.parentNode.removeChild(instance.renderer.domElement);
        }
      }

      // Dispose controls
      if (instance.controls && instance.controls.dispose) {
        instance.controls.dispose();
      }

      // Dispose scene objects
      if (instance.scene) {
        instance.scene.traverse((object) => {
          if (object.geometry) object.geometry.dispose();
          if (object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach(m => m.dispose());
            } else {
              object.material.dispose();
            }
          }
        });
      }

      // Remove stats element if it exists
      if (instance.stats && instance.stats.element && instance.stats.element.parentNode) {
        instance.stats.element.parentNode.removeChild(instance.stats.element);
      }

      delete this.instances[id];
    }
  };

  // Auto-initialize on page load
  function initAll() {
    const viewers = document.querySelectorAll('.bde-3d-model-viewer');
    viewers.forEach((viewer) => {
      const wrapper = viewer.querySelector('.model-viewer-wrapper');
      if (wrapper && wrapper.dataset.modelId) {
        const id = wrapper.dataset.modelId.replace('model-', '');
        window.BreakdanceModelViewer.init('.bde-3d-model-viewer', id);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

})();
