/**
 * OBJLoader - Loader for OBJ files
 * Using CDN version compatible with legacy Three.js
 */
(function loadOBJLoader() {
  'use strict';

  // Wait for THREE.js to be ready
  if (typeof THREE === 'undefined') {
    setTimeout(loadOBJLoader, 50);
    return;
  }

  // Check if OBJLoader already exists
  if (THREE.OBJLoader) {
    return;
  }

  // Use threejsfundamentals CDN which has legacy builds
  const script = document.createElement('script');
  script.src = 'https://threejsfundamentals.org/threejs/resources/threejs/r132/examples/js/loaders/OBJLoader.js';
  script.async = false;

  script.onload = function() {
    console.log('OBJLoader loaded successfully');
  };

  script.onerror = function() {
    console.error('Failed to load OBJLoader from CDN');
  };

  document.head.appendChild(script);
})();
