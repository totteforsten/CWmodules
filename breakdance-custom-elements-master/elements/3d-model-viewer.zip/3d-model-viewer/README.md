# 3D Model Viewer Element for Breakdance

A powerful custom element for Breakdance that allows you to display and interact with 3D models using Three.js.

## Features

- **Multiple Format Support**: GLTF/GLB, FBX, and OBJ file formats
- **Interactive Controls**: Orbit, zoom, and pan controls
- **Auto-Rotation**: Optional automatic rotation with adjustable speed
- **Customizable Lighting**: Ambient and directional lights with color and intensity controls
- **Responsive**: Fully responsive design that adapts to all screen sizes
- **Shadows**: Optional shadow rendering
- **Debug Helpers**: Optional grid and axes helpers for development
- **Loading States**: Beautiful loading animation with progress indicator
- **Error Handling**: Graceful error handling with user-friendly messages

## Supported 3D Model Formats

### GLTF/GLB (Recommended)
- **Best For**: Most use cases, including models with textures, animations, and materials
- **File Extensions**: `.gltf`, `.glb`
- **Advantages**: Compact file size, includes all assets, widely supported

### FBX
- **Best For**: Models exported from Autodesk software (Maya, 3ds Max)
- **File Extension**: `.fbx`
- **Advantages**: Good for complex models with animations

### OBJ
- **Best For**: Simple models, widely compatible
- **File Extension**: `.obj`
- **Note**: Can include separate texture file (`.mtl` or image)

## Usage

1. Add the element to your Breakdance page
2. In the **Content** tab:
   - Select your model type (GLTF, FBX, or OBJ)
   - Enter the URL to your 3D model file
   - For OBJ models, optionally add a texture URL
   - Adjust model scale if needed
   - Configure camera settings (FOV, distance, auto-rotate)
   - Toggle environment helpers (shadows, grid, axes)

3. In the **Design** tab:
   - Set container dimensions (width, height)
   - Customize background color
   - Adjust border radius
   - Configure lighting (ambient and directional)
   - Fine-tune controls (zoom limits, pan, damping)
   - Add spacing (margins)

## Control Buttons

The viewer includes two control buttons in the bottom-right corner:

- **Reset Camera**: Returns the camera to its original position
- **Toggle Auto-Rotate**: Enables/disables automatic rotation

## Configuration Options

### Content Controls

#### 3D Model
- **Model Type**: Choose between GLTF/GLB, FBX, or OBJ
- **Model File URL**: URL to your 3D model file
- **Texture File URL**: (OBJ only) URL to texture file
- **Model Scale**: Scale multiplier (0.1 - 10)

#### Camera
- **Field of View**: Camera FOV angle (10 - 120 degrees)
- **Camera Distance**: Initial distance from model (1 - 50)
- **Auto Rotate**: Enable automatic rotation
- **Auto Rotate Speed**: Rotation speed (-10 to 10)

#### Environment
- **Enable Shadows**: Render shadows on the model
- **Show Grid Helper**: Display ground grid (useful for development)
- **Show Axes Helper**: Display XYZ axes (useful for development)

### Design Controls

#### Container
- **Width**: Container width (supports all units)
- **Height**: Container height (supports all units)
- **Background Color**: Background color behind the model
- **Border Radius**: Rounded corners

#### Lighting
- **Ambient Light Intensity**: Overall ambient lighting (0 - 5)
- **Ambient Light Color**: Color of ambient light
- **Directional Light Intensity**: Main directional light (0 - 5)
- **Directional Light Color**: Color of directional light

#### Controls
- **Enable Zoom**: Allow users to zoom in/out
- **Min Zoom**: Minimum zoom distance (0.1 - 5)
- **Max Zoom**: Maximum zoom distance (0.1 - 10)
- **Enable Pan**: Allow users to pan the camera
- **Enable Smooth Controls**: Enable damping for smooth movement
- **Damping Factor**: Smoothness amount (0.01 - 1)

## Where to Find 3D Models

### Free Resources
- [Sketchfab](https://sketchfab.com/) - Large collection of free 3D models
- [Poly Haven](https://polyhaven.com/models) - High-quality free 3D models
- [Free3D](https://free3d.com/) - Various free 3D models
- [TurboSquid Free](https://www.turbosquid.com/Search/3D-Models/free) - Free section of TurboSquid

### Premium Resources
- [CGTrader](https://www.cgtrader.com/)
- [TurboSquid](https://www.turbosquid.com/)
- [Envato 3D Ocean](https://3docean.net/)

## Tips for Best Results

1. **Model Optimization**: Use optimized models with reasonable polygon counts for web use
2. **File Size**: Keep model files under 10MB for faster loading
3. **Textures**: If using textures, compress them to reduce file size
4. **GLTF Format**: Prefer GLB format (binary GLTF) for best performance
5. **Hosting**: Host your models on a CDN or fast server for quick loading
6. **CORS**: Ensure your model files are accessible (check CORS settings)
7. **Testing**: Test on different devices to ensure performance

## Browser Compatibility

The 3D Model Viewer works on all modern browsers that support WebGL:
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari 14+, Chrome Android)

## Performance Considerations

- **Mobile Devices**: Use lower polygon models for better performance on mobile
- **Shadows**: Disable shadows on mobile for better performance
- **Auto-Rotate**: May impact performance on lower-end devices
- **Multiple Viewers**: Limit the number of 3D viewers on a single page

## Troubleshooting

### Model Not Loading
- Check that the model URL is correct and accessible
- Verify CORS headers allow loading from your domain
- Check browser console for error messages
- Ensure the file format matches the selected type

### Performance Issues
- Reduce model polygon count
- Disable shadows
- Reduce texture resolution
- Disable auto-rotate
- Lower the renderer quality

### Model Appears Too Large/Small
- Adjust the "Model Scale" setting
- Try values between 0.1 and 10 until the model appears correct

### Model Appears Dark
- Increase ambient light intensity
- Increase directional light intensity
- Change light colors to brighter values

## Example Model URLs (for testing)

Here are some publicly available test models you can use:

```
GLTF Models:
https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Box/glTF-Binary/Box.glb
https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Duck/glTF-Binary/Duck.glb
https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Avocado/glTF-Binary/Avocado.glb
```

## Technical Details

- **Three.js Version**: r160
- **Loaders**: GLTFLoader, FBXLoader, OBJLoader
- **Controls**: OrbitControls
- **Renderer**: WebGLRenderer with antialiasing

## Support

For issues or questions, please check the Breakdance documentation or community forums.

## Credits

Built with [Three.js](https://threejs.org/) - The JavaScript 3D Library
